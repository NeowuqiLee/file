<template>
    <div id="app">
        <el-container class="container" direction="vertical">
            <el-header class="header">
                <vheader />
            </el-header>
            <div style="height:100%">
                <el-container>
                    <el-aside width="200px">
                        <navmenu></navmenu>
                    </el-aside>
                    <el-main>
                        <router-view></router-view>
                    </el-main>
                </el-container>
            </div>
        </el-container>
    </div>
</template>
<script>
import NavMenu from '@/components/NavMenu'
import Header from '@/components/Header'

export default {
  name: 'app',
  components: {
    'navmenu': NavMenu,
    'vheader': Header
  }
}

</script>

<style>
.header {
  background-color: #409EFF;
  color: #fff;
  line-height: 60px;
}
</style>
