module.exports = [{
  name: '测试报告',
  id: '1',
  sub: [
    {
      name: '测试任务',
      componentName: 'TestReport'
    }
  ]
}, {
  name: '测试用例',
  id: '2',
  sub: [{
    name: '用例管理',
    componentName: 'TestCase'
  }]
}]
