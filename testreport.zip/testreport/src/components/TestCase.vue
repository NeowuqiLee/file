<template>
  <div style="width: 100%">
    <el-form :inline="true" :model="dataForm" @keyup.enter.native="getDataList()">
      <!-- <el-form-item label="用例名称">
        <el-input type="text" v-model="dataForm.scriptname" style="width: 200px"></el-input>
      </el-form-item> -->
      <el-form-item>
        <!-- <el-button type="primary" @click="getDataList()">查询</el-button> -->
        <el-button type="primary" @click="createOrUpdateHandle()">创建测试用例</el-button>
        <el-button type="primary" @click="createTestTask()">创建测试任务</el-button>
      </el-form-item>
    </el-form>
      <el-table :data="dataList.slice((currentPage-1)*pageSize,currentPage*pageSize)" border stripe style="width: 100%;"
              :default-sort = "{prop: 'createtime', order: 'descending'}"
              :cell-style="{padding: '0', height: '60px'}">
      <el-table-column prop="scriptid" label="ID" align="center" :show-overflow-tooltip="true" min-width="50px">
      </el-table-column>
      <el-table-column prop="description" label="模块" align="center" :show-overflow-tooltip="true" min-width="100px"
                       :filters="descriptions" :filter-method="filterHandler">
      </el-table-column>
      <el-table-column prop="scriptname" label="用例名称" align="center" :show-overflow-tooltip="true" min-width="300px">
      </el-table-column>
      <el-table-column prop="ostype" label="系统类型" align="center" :show-overflow-tooltip="true" min-width="100px"
                       :filters="[{text: 'iOS', value: 'iOS'}, {text: 'Android', value: 'Android'}]"
                       :filter-method="filterHandler">
      </el-table-column>
      <el-table-column prop="creator" label="创建人" align="center" :show-overflow-tooltip="true" min-width="100px"
                       :filters="creators" :filter-method="filterHandler">
      </el-table-column>
      <el-table-column prop="createtime" label="更新时间" align="center" sortable
                       :show-overflow-tooltip="true" min-width="150px">
      </el-table-column>

      <el-table-column label="操作" fixed="right" align="center" min-width="150px">
        <template slot-scope="scope">
          <el-button type="text"  @click="getTestCaseDetail(scope.row)">查看</el-button>
          <el-button v-if="isDisplay(scope.row.creator)" type="text"
                     @click="createOrUpdateHandle(scope.row)">编辑</el-button>
          <el-button v-if="isDisplay(scope.row.creator)" type="text"
                     @click="copyTestCase(scope.row)">复制</el-button>

          <el-button v-if="scope.row.projectid === 0" type="text"
                     @click="testCaseDebug(scope.row.scriptid)">调试</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页器 -->
    <div class="block" style="margin-top:15px;float: left">
      <el-pagination align='center' @size-change="handleSizeChange"
                     @current-change="handleCurrentChange"
                     background
                     :current-page="currentPage"
                     :page-sizes="[10,20,30,50]"
                     :page-size="pageSize"
                     layout="total, sizes, prev, pager, next"
                     :total="dataList.length">
      </el-pagination>
    </div>
    <!-- 弹窗, 新增 / 修改 -->
    <tcCreateOrUpdate v-if="createOrUpdateVisible" ref="refUpdate" @refreshTcList="getDataList"></tcCreateOrUpdate>
    <tcPreview v-if="tcPreviewVisible" ref="refPreview" @refreshTcList="getDataList"></tcPreview>
    <testTaskCreate v-if="testTaskVisible" ref="refTestTask" @refreshTcList="getDataList"></TestTaskCreate>

  </div>
</template>

<script>
import tcCreateOrUpdate from './TestCaseCreateOrUpdate'
import tcPreview from './TestCasePreview'
import testTaskCreate from './TestTaskCreate'
export default {
  name: 'TestCase',
  data () {
    return {
      currentPage: 1, // 当前页码
      total: 10, // 总条数
      pageSize: 10, // 每页的数据条数
      creators: [],
      dataList: [],
      dataForm: {},
      descriptions: [],
      dataListLoading: false,
      createOrUpdateVisible: false,
      tcPreviewVisible: false,
      testTaskVisible: false
    }
  },
  components: {
    tcCreateOrUpdate,
    tcPreview,
    testTaskCreate
  },
  created () {
    this.getDataList()
  },
  methods: {
    handleSizeChange (size) {
      // console.log(`每页 ${size} 条`)
      this.pageSize = size
    },
    handleCurrentChange (currentPage) {
      // console.log(`当前页: ${currentPage}`)
      this.currentPage = currentPage
    },
    getDataList () {
      this.dataListLoading = true
      this.$http.get('http://127.0.0.1:8300/getTestCases').then(response => {
        if (response.status === 200) {
          this.dataList = response.data.data
          const set = new Set((this.dataList || []).map(item => item.creator))
          const descriptionSet = new Set((this.dataList || []).map(item => item.description))
          this.creators = [...set].map(item => {
            return {
              text: item,
              value: item
            }
          })
          this.descriptions = [...descriptionSet].map(item => {
            return {
              text: item,
              value: item
            }
          })
          this.dataListLoading = false
        }
      }, response => {
        // error callback
      })
    },
    isDisplay (creator) {
      return true
      // if (this.$store.state.name === 'wuqi.li') {
      //   return true
      // } else {
      //   return this.$store.state.name === creator
      // }
    },
    getTestCaseDetail (row) {
      this.tcPreviewVisible = true
      this.$nextTick(() => {
        this.$refs.refPreview.init(row)
      })
    },
    // 创建或者修改row
    createOrUpdateHandle (row) {
      this.createOrUpdateVisible = true
      this.$nextTick(() => {
        this.$refs.refUpdate.init(row)
      })
      // setTimeout(() => {
      //   this.$refs.refUpdate.init(scriptid)
      // }, 300)
    },
    copyTestCase (row) {
      this.$http.post('http://127.0.0.1:8300/copyTestCase',
        row
      ).then(response => {
        if (response.status === 200) {
          this.$message({
            message: response.data.copy_desc,
            type: 'success',
            duration: 1500
          })
          this.getDataList()
        } else {
          this.$message.error('copy error')
        }
      }, response => {
        // error callback
        this.$message.error('http error')
      })
    },
    filterHandler (value, row, column) {
      const property = column['property']
      return row[property] === value
    },
    async testCaseDebug (scriptid) {
      // window.open('http://127.0.0.1:8100/remote', '_blank')
      try {
        await this.$http({
          url: 'http://127.0.0.1:8300/debug?scriptid=' + scriptid,
          method: 'get',
          params: {}
        })
      } catch (err) {
        console.error(err)
      }
    },
    createTestTask () {
      this.testTaskVisible = true
      this.$nextTick(() => {
        this.$refs.refTestTask.init()
      })
      // setTimeout(() => {
      //   this.$refs.refTestTask.init()
      // }, 300)
    }
  }
}
</script>

<style scoped>

</style>
