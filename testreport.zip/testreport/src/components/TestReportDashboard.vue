<template>
  <el-dialog
    title="报告详情"
    :close-on-click-modal="false"
    width="1400px"
    :visible.sync="trVisible"
    @close="closeModal"
  >
    <div style="text-align: right; padding-bottom: 20px;">
      <el-button type="primary" @click="sendTaskDetail()">发送报告</el-button>
    </div>
    <el-table :data="taskDataList" border stripe style="width: 100%;">
      <el-table-column
        v-for="(title, index) of task_title"
        :key="index"
        :prop="title.prop"
        :label="title.label"
        header-align="center"
        align="center"
        :show-overflow-tooltip="true"
        :min-width="title.width"
      ></el-table-column>
    </el-table>
    <br />
    <el-table :data="resultDataList" border stripe style="width: 100%;">
      <el-table-column
        v-for="(title, index) of base_title"
        :key="index"
        :prop="title.prop"
        :label="title.label"
        header-align="center"
        align="center"
        :show-overflow-tooltip="true"
        :min-width="title.width"
      ></el-table-column>
      <el-table-column label="操作" fixed="right" align="center" min-width="150px">
        <template slot-scope="scope">
          <el-button
            type="text"
            size="small"
            @click="getExeDetail(scope.row.taskid, scope.row.caseid, scope.row.stepinfo,scope.row.casename)"
          >查看详情</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 弹窗, 新增 / 修改 -->
    <TestCaseExeDetails v-if="exeDetailsVisible" ref="TestCaseExeDetails"></TestCaseExeDetails>
  </el-dialog>
</template>

<script>
import TestCaseExeDetails from './TestCaseExeDetails'
export default {
  name: 'TestReportDashboard',
  data () {
    return {
      task: {},
      taskDataList: [],
      resultDataList: [],
      trVisible: false,
      exeDetailsVisible: false,
      task_title: [
        { prop: 'taskid', label: '任务ID', width: '50px' },
        { prop: 'taskname', label: '任务名称', width: '300px' },
        { prop: 'deviceinfo', label: '机型信息', width: '120px' },
        { prop: 'taskresult', label: '成功，失败，总数', width: '120px' },
        { prop: 'appversion', label: 'APP版本', width: '120px' },
        { prop: 'createtime', label: '执行时间', width: '180px' }
      ],
      base_title: [
        { prop: 'caseid', label: '用例ID', width: '50px' },
        { prop: 'casename', label: '用例名称', width: '310px' },
        { prop: 'tooltype', label: '驱动工具', width: '120px' },
        { prop: 'umid', label: '用例作者', width: '90px' },
        { prop: 'loginfo', label: '系统类型', width: '90px' },
        { prop: 'state', label: '执行结果', width: '90px' }
      ]
    }
  },
  components: {
    TestCaseExeDetails
  },
  methods: {
    init (taskid) {
      if (taskid) {
        this.$http
          .get('http://127.0.0.1:8300/getReportByTaskid?taskid=' + taskid)
          .then(response => {
            if (response.status === 200) {
              this.$nextTick(() => {
                this.task = response.data.task_desc.taskname
                this.taskDataList = response.data.task_desc
                this.resultDataList = response.data.task_dtail
              })
              this.trVisible = true
            } else {
              this.$message.error('测试任务ID为空，无法获取数据！！')
            }
          })
      }
    },
    getExeDetail (taskid, caseid, stepinfo, casename) {
      this.exeDetailsVisible = true
      this.$nextTick(() => {
        this.$refs.TestCaseExeDetails.init(taskid, caseid, stepinfo, casename)
      })
    },
    closeModal () {
      this.trVisible = false
    },
    sendTaskDetail () {
      this.$http({
        url: this.$http.adornUrl(`/uiauto/result/sendTask/` + this.task.taskid),
        method: 'get',
        params: this.$http.adornParams()
      }).then(alert('报告发送成功！'))
    }
  }
}
</script>

<style scoped>
.success-status {
  color: #67c23a;
  font-weight: bold;
}
.fail-status {
  color: #f56c6c;
  font-weight: bold;
}
</style>
