<template>
  <el-dialog :title="!addOrUpdateStatus ? '创建用例' : '修改用例'" :close-on-click-modal="false"
    width="1600px" :visible.sync="visible" @close="closeModal">
    <el-form ref="ruleForm" :inline="true" :model="formData" :rules="rules">
      <el-row>
          <el-form-item label="模块" prop="description">
            <el-input v-model="formData.description"></el-input>
          </el-form-item>
          <el-form-item label="用例名称" prop="scriptname">
            <el-input v-model="formData.scriptname"></el-input>
          </el-form-item>
          <el-form-item label="系统类型" prop="ostype" >
            <el-select v-model="formData.ostype">
              <el-option v-for="(item, index) in os_types"
                         :key="index"
                         :label="item.label"
                         :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="创建人" prop="creator">
            <el-input :disabled="true" v-model="formData.creator"></el-input>
          </el-form-item>
          <el-form-item label="是否执行通过" prop="projectid">
            <el-select v-model="formData.projectid">
              <el-option v-for="(item, index) in projectIds"
                         :key="index"
                         :label="item.label"
                         :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
      </el-row>
      <br>
      <p style="font-size: 16px">测试步骤</p>
      <el-table :data="formData.steps" border max-height="500px" style="margin-top: 10px;">
        <el-table-column type="index" label="步骤" width="50"></el-table-column>
        <el-table-column align="center" width="50" label="新增">
          <template slot-scope="scope">
            <el-button type="text" @click="addStep(scope.row, scope.$index)" icon="el-icon-plus"></el-button>
          </template>
        </el-table-column>
        <!--<el-table-column align="center" label="控件类型">
          <template slot-scope="scope">
            <el-form-item :rules="{ required: true, message: '请选择控件类型', trigger: 'blur' }"
                          :prop="'steps.' + scope.$index + '.element_type'">
              <el-select v-model="scope.row.element_type">
                <el-option v-for="(item, index) in element_types"
                           :key="index"
                           :label="item.label"
                           :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </template>
        </el-table-column>-->
        <el-table-column align="center" label="操作描述">
          <template slot-scope="scope">
            <el-form-item :rules="{ required: true, message: '请输入控件名称', trigger: 'blur' }"
                          :prop="'steps.' + scope.$index + '.element_name'">
              <el-input v-model="scope.row.element_name"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column align="center" label="查找方式">
          <template slot-scope="scope">
            <el-form-item :rules="{ required: true, message: '请选择查找方式', trigger: 'blur' }"
                          :prop="'steps.' + scope.$index + '.find_method'">
              <el-select v-model="scope.row.find_method">
                <el-option v-for="(item, index) in find_methods"
                           :key="index"
                           :label="item.label"
                           :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column align="center" label="控件标识">
          <template slot-scope="scope">
            <el-form-item :rules="{ required: true, message: '请输入控件标识', trigger: 'blur' }"
                          :prop="'steps.' + scope.$index + '.find_method_value'">
              <el-input v-model="scope.row.find_method_value"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column align="center" label="索引">
          <template slot-scope="scope">
            <el-form-item>
              <el-select v-model="scope.row.ui_index" >
                <el-option v-for="(item, index) in ui_indexs"
                           :key="index"
                           :label="item.label"
                           :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column align="center" label="动作类型">
          <template slot-scope="scope">
            <el-form-item :rules="{ required: true, message: '请选择动作类型', trigger: 'blur' }"
                          :prop="'steps.' + scope.$index + '.action_type'">
              <el-select v-model="scope.row.action_type">
                <el-option v-for="(item, index) in action_types"
                           :key="index"
                           :label="item.label"
                           :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column align="center" label="参数">
          <template slot-scope="scope">
            <el-form-item>
            <el-input v-model="scope.row.action_parameter"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
        <!--<el-table-column align="center" label="超时时间(ms)">
          <template slot-scope="scope">
            <el-form-item :rules="{ required: true, message: '请输入超时时间', trigger: 'blur' }"
                          :prop="'steps.' + scope.$index + '.action_timeout'">
              <el-input v-model="scope.row.action_timeout"></el-input>
            </el-form-item>
          </template>
        </el-table-column>-->
        <el-table-column align="center" label="操作">
          <template slot-scope="scope">
            <el-button type="text" :disabled="scope.$index < 1" @click="upStep(formData.steps, scope.$index)">上移</el-button>
            <el-button type="text" :disabled="scope.$index >= formData.steps.length-1" @click="downStep(formData.steps, scope.$index)">下移</el-button>
            <el-button type="text" :disabled="formData.steps.length <= 1" @click="removeField(scope.$index)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-form>
    <div class="el-dialog__footer">
      <el-button type="cancle" @click="closeModal">取消</el-button>
      <el-button type="success" @click="handleSave">保存</el-button>
    </div>
  </el-dialog>
</template>

<script>
export default {
  name: 'TestCaseCreateOrUpdate',
  data () {
    return {
      visible: false,
      addOrUpdateStatus: false,
      formData: {
        creator: '',
        description: '',
        ostype: '',
        scriptname: '',
        steps: []
      },
      os_types: [
        {
          value: 'iOS',
          label: 'iOS'
        }, {
          value: 'Android',
          label: 'Android'
        }
      ],
      element_types: [
        {
          value: 'web',
          label: 'web'
        }, {
          value: 'native',
          label: 'native'
        }
      ],
      projectIds: [
        {
          value: 0,
          label: '否'
        }, {
          value: 1,
          label: '是'
        }
      ],
      find_methods: [
        {value: 'id', label: 'id'},
        {value: 'name', label: 'name'},
        {value: 'xpath', label: 'xpath'},
        {value: 'class', label: 'class'},
        {value: 'label', label: 'label'}
      ],
      ui_indexs: [
        {value: '-1', label: '-1'},
        {value: '0', label: '0'},
        {value: '1', label: '1'},
        {value: '2', label: '2'},
        {value: '3', label: '3'},
        {value: '4', label: '4'}
      ],
      action_types: [
        {value: 'click', label: '点击'},
        {value: 'isExist', label: '是否存在'},
        {value: 'setText', label: '设置输入值'},
        {value: 'clearText', label: '清空输入值域'},
        {value: 'swipeUp', label: '上滑'},
        {value: 'swipeDown', label: '下滑'},
        {value: 'swipeLeft', label: '左滑'},
        {value: 'swipeRight', label: '右滑'},
        {value: 'existGoto', label: '存在即跳转'},
        {value: 'notExistGoto', label: '不存在即跳转'},
        {value: 'wait', label: '等待'}
      ],
      rules: {
        creator: [{ required: true, message: '请输入创建者', trigger: 'blur' }],
        description: [{ required: true, message: '请输入描述', trigger: 'blur' }],
        ostype: [{ required: true, message: '请选择系统类型', trigger: 'blur' }],
        scriptname: [{ required: true, message: '请输入脚本名', trigger: 'blur' }]
      }
    }
  },
  methods: {
    async init (row) {
      this.addOrUpdateStatus = false
      this.resetSteps()
      if (row) {
        this.addOrUpdateStatus = true
        this.formData = row
        this.formData.steps = JSON.parse(row.step)
      } else {
        // this.formData.creator = this.$store.state.name
        this.formData.creator = 'wuqili'
        this.formData.projectid = 0
        this.formData.projectid = 0
        this.formData.ostype = 'iOS'
        this.formData.steps = [
          {element_type: 'native',
            find_method: 'name',
            ui_index: '0',
            action_type: 'click'
          }
        ]
      }
      this.visible = true
    },
    addStep (row, index) {
      let item = Object.assign({}, row)
      if (index !== undefined) {
        this.formData.steps.splice(index + 1, 0, item)
      } else {
        this.formData.steps.push(item)
      }
    },
    swapArray (arr, index1, index2) {
      arr[index1] = arr.splice(index2, 1, arr[index1])[0]
      return arr
    },
    upStep (arr, index) {
      this.swapArray(arr, index, index - 1)
    },
    downStep (arr, index) {
      this.swapArray(arr, index, index + 1)
    },
    removeField (index) {
      this.formData.steps.splice(index, 1)
    },
    resetSteps () {
      const steps = [
        {
          element_type: '',
          element_name: '',
          find_method: '',
          find_method_value: '',
          ui_index: '',
          action_type: '',
          action_parameter: '',
          action_timeout: ''
        }
      ]
      this.formData = {
        creator: '',
        description: '',
        ostype: '',
        scriptname: '',
        steps: steps
      }
      if (this.$refs['ruleForm']) {
        this.$nextTick(() => {
          this.$refs['ruleForm'].clearValidate()
        })
      }
    },
    closeModal () {
      this.visible = false
    },
    handleSave () {
      this.$refs['ruleForm'].validate(async valid => {
        if (valid) {
          if (this.formData.steps.length === 0) {
            this.$message.error('请添加测试步骤')
            return
          } else if (
            this.formData.steps.some(item => {
              return !(item.element_type && item.element_name && item.find_method && item.find_method_value &&
                  item.action_type)
            })
          ) {
            this.$message.error('请输入测试步骤必填字段')
            return
          }
          let data = {
            creator: this.formData.creator,
            description: this.formData.description,
            ostype: this.formData.ostype,
            projectid: this.formData.projectid,
            scriptname: this.formData.scriptname,
            step: JSON.stringify(this.formData.steps)
          }
          this.formData.scriptid && (data.scriptid = this.formData.scriptid)
          this.$http.post('http://127.0.0.1:8300/updateTestCase',
            data
          ).then(response => {
            if (response.status === 200) {
              this.$message({
                message: response.data.update_desc,
                type: 'success',
                duration: 1500,
                onClose: () => {
                  this.visible = false
                  this.addOrUpdateStatus = false
                  this.$emit('refreshTcList')
                }
              })
            } else {
              this.$message.error('update error')
            }
          }, response => {
            // error callback
            this.$message.error('http error')
          })
        }
      })
    }
  }
}
</script>

<style scoped>

</style>
