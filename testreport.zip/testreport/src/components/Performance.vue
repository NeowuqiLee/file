<template>
  <el-dialog title="性能页面" :close-on-click-modal="false" width="1200px" :visible.sync="performanceVisible" @close="closeModal">
    <h1>404</h1>
  </el-dialog>
</template>

<script>
export default {
  name: 'Performance',
  data () {
    return {
      performanceVisible: false
    }
  },
  methods: {
    init () {
      this.performanceVisible = true
    },
    closeModal () {
      this.edVisible = false
    }
  }
}
</script>

<style scoped>

</style>
