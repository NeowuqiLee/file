<template>
  <div>
    <el-table
      :data="tableData.slice((currentPage-1)*pageSize,currentPage*pageSize)"
      border
      stripe
      style="width: 100%;"
      :default-sort="{prop: 'createtime', order: 'descending'}"
      :cell-style="{padding: '0', height: '70px'}"
    >
      <el-table-column
        v-for="(title, index) of base_title"
        :key="index"
        :prop="title.prop"
        :label="title.label"
        :sortable="title.sortable"
        align="center"
        :show-overflow-tooltip="true"
        :min-width="title.width"
      ></el-table-column>
      <el-table-column label="操作" align="center" min-width="80px">
        <template slot-scope="scope">
          <el-button type="text" @click="getTestReportDashboard(scope.row.taskid)">UI报告</el-button>
          <el-button type="text" @click="getInterfaceDashboard(scope.row.taskid)">接口报告</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页器 -->
    <div class="block" style="margin-top:15px;float: left">
      <el-pagination
        align="center"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        background
        :current-page="currentPage"
        :page-sizes="[10,20,30,50]"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next"
        :total="tableData.length"
      ></el-pagination>
    </div>
    <!-- 弹窗, 新增 / 修改 -->
    <testReportDashboard
      v-if="dashboardVisible"
      ref="refTestReportDashboard"
      @refreshTrList="getTableData"
    ></testReportDashboard>
    <traceInterface v-if="interfaceVisible" ref="refInterface" @refreshTrList="getTableData"></traceInterface>
  </div>
</template>

<script>
import testReportDashboard from './TestReportDashboard'
import traceInterface from './TraceInterface'
export default {
  name: 'TestReport',
  data () {
    return {
      currentPage: 1, // 当前页码
      // total: 10, // 总条数
      pageSize: 10, // 每页的数据条数
      options: [],
      tableData: [],
      dataListLoading: false,
      base_title: [
        { prop: 'taskid', label: 'ID', width: '40px', sortable: false },
        {
          prop: 'taskname',
          label: '任务名称',
          width: '150px',
          sortable: false
        },
        {
          prop: 'projectname',
          label: '应用名称',
          width: '80px',
          sortable: false
        },
        { prop: 'appversion', label: '版本', width: '50px', sortable: false },
        { prop: 'ostype', label: '系统', width: '50px', sortable: false },
        {
          prop: 'taskstate',
          label: '任务状态',
          width: '50px',
          sortable: false
        },
        {
          prop: 'taskresult',
          label: '成功,失败,总数',
          width: '100px',
          sortable: false
        },
        {
          prop: 'passingrate',
          label: '通过率',
          width: '50px',
          sortable: false
        },
        { prop: 'umid', label: '执行人', width: '50px', sortable: false },
        {
          prop: 'createtime',
          label: '创建时间',
          width: '150px',
          sortable: true
        }
      ],
      dashboardVisible: false,
      interfaceVisible: false
    }
  },
  components: {
    testReportDashboard,
    traceInterface
  },
  created () {
    this.getTableData()
  },
  methods: {
    handleSizeChange (size) {
      // console.log(`每页 ${size} 条`)
      this.pageSize = size
    },
    handleCurrentChange (currentPage) {
      // console.log(`当前页: ${currentPage}`)
      this.currentPage = currentPage
    },
    getTableData () {
      this.$http.get('http://127.0.0.1:8300/getTestReports').then(
        response => {
          if (response.status === 200) {
            response.data.data.forEach(element => {
              let taskResult = element.taskresult
              // console.log(taskResult)
              if (taskResult.indexOf('null') === -1) {
                let taskResultArr = taskResult.split(',')
                element['passingrate'] =
                  (taskResultArr[0] / taskResultArr[2]) * 100 + '%'
              }
            })
            this.tableData = response.data.data
          }
        },
        response => {
          // error callback
        }
      )
    },
    getTestReportDashboard (taskid) {
      this.dashboardVisible = true
      this.$nextTick(() => {
        this.$refs.refTestReportDashboard.init(taskid)
      })
    },
    getInterfaceDashboard (taskid) {
      this.interfaceVisible = true
      this.$nextTick(() => {
        this.$refs.refInterface.init(taskid)
      })
    }
  }
}
</script>

<style scoped>
.el-aside {
  height: 100vh;
}
</style>
