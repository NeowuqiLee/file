<template>
  <el-dialog title="用例详情" :close-on-click-modal="false" width="1600px"
             :visible.sync="tcVisible" @close="closeModal">
    <el-table :data="dataList" border stripe style="width: 100%;">
      <el-table-column v-for="(title, index) in base_title" :key="index" :prop="title.prop"
                       :label="title.label"
                       header-align="center"
                       align="center" :show-overflow-tooltip="true"
                       min-width="150">
        <template slot-scope="scope">
          <span v-if="title.prop !== 'projectid'">{{scope.row[title.prop]}}</span>
          <span v-if="title.prop === 'projectid'" style="font-size:20px">{{scope.row[title.prop] | filterByPass}}</span>
        </template>
      </el-table-column>
    </el-table>
    <br>
    <p style="font-size: 18px">测试步骤</p>
    <el-table :data="stepList" border stripe height="500px" style="width: 100%;">
      <el-table-column type="index" label="步骤" width="50"></el-table-column>
      <el-table-column v-for="(title, index) of step_title" :key="index" :prop="title.prop"
                       :label="title.label"
                       header-align="center"
                       align="center" :show-overflow-tooltip="true"
                       min-width="150">
      </el-table-column>
    </el-table>
  </el-dialog>
</template>

<script>
export default {
  name: 'TestCasePreview',
  data () {
    return {
      dataList: [],
      stepList: [],
      tcVisible: false,
      base_title: [
        {prop: 'description', label: '模块'},
        {prop: 'scriptname', label: '用例名称'},
        {prop: 'ostype', label: '系统类型'},
        {prop: 'creator', label: '创建人'},
        {prop: 'projectid', label: '是否执行通过'}
      ],
      step_title: [
        // {prop: 'element_type', label: '控件类型'},
        {prop: 'element_name', label: '控件名称'},
        {prop: 'find_method', label: '查找方式'},
        {prop: 'find_method_value', label: '控件标识'},
        {prop: 'ui_index', label: '索引'},
        {prop: 'action_type', label: '动作类型'},
        {prop: 'action_parameter', label: '参数'}
        // {prop: 'action_timeout', label: '超时时间(ms)'}
      ]
    }
  },
  filters: {
    filterByPass (value) {
      switch (value) {
        case 0:
          return '否'
        case 1:
          return '是'
      }
    }
  },
  methods: {
    init (row) {
      if (row) {
        this.tcVisible = true
        this.$nextTick(() => {
          this.stepList = JSON.parse(row.step)
          const propSet = new Set((this.base_title).map(item => item.prop))
          const tempObj = {}
          Object.keys(row).forEach(element => {
            if (propSet.has(element)) {
              tempObj[element] = row[element]
            }
          })
          this.dataList = [tempObj]
        })
      } else {
        this.$message.error('测试用例ID为空，无法获取数据！！')
      }
    },
    closeModal () {
      this.tcVisible = false
    }
  }
}
</script>

<style scoped>

</style>
