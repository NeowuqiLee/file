<template>
  <el-dialog
    title="接口详情"
    :close-on-click-modal="false"
    width="1400px"
    :visible.sync="trVisible">
      <el-table
        :data="dataList"
        border
        stripe
        style="width:100%;"
      >
        <el-table-column
          prop="uielement"
          label="UI事件（请求数量）"
          align="center"
          :show-overflow-tooltip="true"
          min-width="150px"
        >
          <template slot-scope="scope">
            <span style="color: #17B3A3">{{ scope.row.uielement }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="startTime"
          label="时间戳(s)"
          :formatter="dateFormat"
          align="center"
          :show-overflow-tooltip="true"
          min-width="150px"
        ></el-table-column>
        <el-table-column
          prop="url"
          label="接口"
          align="center"
          :show-overflow-tooltip="true"
          min-width="450px"
        ></el-table-column>
        <el-table-column
          prop="time"
          label="耗时(ms)"
          align="center"
          :show-overflow-tooltip="true"
          min-width="100px"
        >
          <template slot-scope="scope">
            <span v-if="scope.row.time > 200" style="color: red">
              {{
              scope.row.time
              }}
            </span>
            <span v-else>{{ scope.row.time }}</span>
          </template>
        </el-table-column>
        <el-table-column label="接口详情" align="center" min-width="100px">
          <template slot-scope="scope" v-if="scope.row.uielement == ''">
            <el-button type="text"  @click="showReq(scope.row.req)">请求</el-button>
            <el-button type="text"  @click="showRes(scope.row.res)">响应</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-dialog title="Request" :visible.sync="reqVisible" width="60%" :append-to-body='true'>
        <JsonViewer :value="req" :expand-depth=3 expanded copyable boxed></JsonViewer>
      </el-dialog>
      <el-dialog title="Response" :visible.sync="resVisible" width="60%"
      :append-to-body='true'>
        <JsonViewer :value="res" :expand-depth=3 expanded  copyable boxed></JsonViewer>
        <!-- <span slot="footer" class="dialog-footer">
          <el-button @click="resVisible = false">取 消</el-button>
          <el-button type="primary" @click="resVisible = false">确 定</el-button>
        </span> -->
      </el-dialog>
      <!-- 弹窗, 性能数据 -->
      <!-- <performance-data
        v-if="performanceVisible"
        ref="stepinfoAndPerformance"
        @refreshTcList="getDataList"
      ></performance-data> -->
  </el-dialog>
</template>

<script>
import moment from 'moment'
import JsonViewer from 'vue-json-viewer'
import performanceData from './Performance'
export default {
  name: 'TraceInterface',
  data () {
    return {
      dataList: [],
      res: '',
      req: '',
      trVisible: false,
      reqVisible: false,
      resVisible: false
    }
  },
  components: {
    performanceData,
    JsonViewer
  },
  methods: {
    init (taskid) {
      if (taskid) {
        this.$http
          .get('http://127.0.0.1:8300/getUItrace?taskid=' + taskid)
          .then(response => {
            if (response.status === 200) {
              this.$nextTick(() => {
                this.dataList = response.data.data
              })
              this.trVisible = true
            } else {
              this.$message.error('测试任务ID为空，无法获取数据！')
            }
          })
      }
    },
    closeModal () {
      this.trVisible = false
    },
    showRes (res) {
      this.resVisible = true
      this.res = res
    },
    showReq (req) {
      this.reqVisible = true
      this.req = req
    },
    dateFormat (row, column) {
      const date = row[column.property]
      if (date === undefined) {
        return ' '
      }
      return moment(date).format('YYYY-MM-DD HH:mm:ss-SSS')
    }
  }
}
</script>

<style scoped>
.el-table--striped .el-table__body td.column-background {
  background: #17b3a3;
  /*#17B3A3*/
  border-bottom: 1px solid #dadada;
}
</style>
