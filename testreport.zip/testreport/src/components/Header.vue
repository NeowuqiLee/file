<template>
  <el-row>
    <el-col :span="24">
      <div class="head-wrap">UI自动化</div>
    </el-col>
  </el-row>
</template>

<style scoped>
.head-wrap{
  text-align: left;;
  font-size:x-large;

}
</style>
