<template>
  <el-dialog :title="this.caseid+'-'+this.casename" :close-on-click-modal="false" width="1400px"
             :visible.sync="edVisible" @close="closeModal" append-to-body >
    <div class="clearfix el-dialog_body">
      <el-table :data="dataList" border stripe style="float: left; width: 410px">
        <el-table-column type="index" label="序号" width="50"></el-table-column>
        <el-table-column prop="uielement"
                         label="UI元素"
                         header-align="center"
                         align="center"
                        :show-overflow-tooltip="true"
                         min-width="100">
        </el-table-column>
        <el-table-column
          label="执行结果"
          header-align="center"
          align="center"
          :show-overflow-tooltip="true"
          min-width="100">
          <template slot-scope="scope">
            <div v-if="scope.row.stepresult === 'success'" class="success-status">
              <i class="el-icon-check"></i>
              <span>成功</span>
            </div>
            <div v-if="scope.row.stepresult === 'fail'" class="fail-status">
              <i class="el-icon-close"></i>
              <span>失败</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          prop="timestamp"
          label="时间"
          :formatter="dateFormat"
          align="left"
          :show-overflow-tooltip="true"
          min-width="200px"
        ></el-table-column>
      </el-table>
      <div class="demo-image" style="float: right; width: 880px">
        <img v-for="url in urls" :key="url" :src="url" alt="" style="width: 220px; object-fit: scale-down;">
      </div>
    </div>
  </el-dialog>
</template>

<script>
import moment from 'moment'
export default {
  name: 'TestCaseExeDetails',
  data () {
    return {
      caseid: '',
      casename: '',
      dataList: [],
      urls: [],
      edVisible: false,
      base_title: [
        {prop: 'uielement', label: 'UI元素'},
        {prop: 'stepresult', label: '执行结果'}
      ]
    }
  },
  methods: {
    init (taskid, caseid, stepinfo, casename) {
      if (stepinfo) {
        this.caseid = caseid
        this.casename = casename
        this.$nextTick(() => {
          this.dataList = JSON.parse(stepinfo)
          this.urls = []
          for (var i = 0; i < this.dataList.length; i++) {
            let ip = '127.0.0.1'
            this.urls.push('http://' + ip + ':8070/img/' + taskid + '/' + caseid + '-' +
                  this.dataList[i].uielement + '.png')
          }
          this.edVisible = true
        })
      } else {
        this.$message.error('测试步骤为空，无法获取数据！！')
      }
    },
    dateFormat (row, column) {
      /* eslint-disable */
      const date = row[column.property]*1000
      if (date === undefined) {
        return ' '
      }
      return moment(date).format('YYYY-MM-DD HH:mm:ss')
    },
    closeModal () {
      this.edVisible = false
    }
  }
}
</script>

<style scoped>
.success-status {
  color: #67c23a;
  font-weight: bold;
}
.fail-status {
  color: #f56c6c;
  font-weight: bold;
}
.el-dialog_body{
  height: 50v;
  background-color: white;
  overflow: auto;
}
</style>
