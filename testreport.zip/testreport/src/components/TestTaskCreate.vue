<template>
  <el-dialog title="创建测试任务" :close-on-click-modal="false"
             width="1200px" :visible.sync="visible" @close="closeModal">
      <el-form ref="form" :model="formData" :rules="rules" size="small" label-width="80px" style="margin: 0 30px;">
        <el-row>
          <el-col :span="12">
            <el-form-item label="任务名称" prop="taskName">
              <el-input v-model="formData.taskName"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col>
            <el-table ref="multipleTable" :data="dataList"  border stripe max-height="500" @selection-change="selectionChange" @filter-change="filterChange">
              <el-table-column type="selection" width="55"></el-table-column>
              <el-table-column prop="scriptid" label="ID" align="center" :show-overflow-tooltip="true" min-width="50px">
              </el-table-column>
              <el-table-column prop="description" label="模块" align="center" :show-overflow-tooltip="true" min-width="100px"
                              :filters="descriptions" :filter-method="filterHandler">
              </el-table-column>
              <el-table-column prop="scriptname" label="用例名称" align="center" :show-overflow-tooltip="true" min-width="300px">
              </el-table-column>
              <el-table-column prop="ostype" label="系统类型" align="center" :show-overflow-tooltip="true" min-width="100px"
                              :filters="[{text: 'iOS', value: 'iOS'}, {text: 'Android', value: 'Android'}]"
                              :filter-method="filterHandler">
              </el-table-column>
              <el-table-column prop="creator" label="创建人" align="center" :show-overflow-tooltip="true" min-width="100px"
                              :filters="creators" :filter-method="filterHandler">
              </el-table-column>
              <el-table-column prop="createtime" label="更新时间" align="center" sortable
                              :show-overflow-tooltip="true" min-width="150px">
              </el-table-column>
            </el-table>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer">
        <el-button type="cancel" @click="closeModal">取消</el-button>
        <el-button :loading="loading" type="success" @click="doExecute">执行任务</el-button>
      </div>
  </el-dialog>
</template>

<script>
export default {
  name: 'TestTaskCreate',
  data () {
    return {
      visible: false,
      loading: false,
      creators: [],
      dataList: [],
      selectedRows: [],
      descriptions: [],
      dataForm: {},
      formData: {
        taskName: ''
      },
      rules: {
        taskName: [
          { required: true, message: '请输入任务名称', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    async init () {
      this.dataList = []
      this.selectedRows = []
      this.$http.get('http://127.0.0.1:8300/getTestCases').then(response => {
        if (response.status === 200) {
          this.dataList = response.data.data
          const set = new Set((this.dataList || []).map(item => item.creator))
          const descriptionSet = new Set((this.dataList || []).map(item => item.description))
          this.creators = [...set].map(item => {
            return {
              text: item,
              value: item
            }
          })
          this.descriptions = [...descriptionSet].map(item => {
            return {
              text: item,
              value: item
            }
          })
        }
        this.visible = true
        this.$nextTick(() => {
          this.resetForm()
        })
      })
    },
    filterHandler (value, row, column) {
      const property = column['property']
      return row[property] === value
    },
    filterChange () {
      this.selectedRows = []
      this.$refs.multipleTable.clearSelection()
    },
    selectionChange (rows) {
      // console.log('selectionChange: ', rows)
      this.selectedRow = rows
    },
    doExecute () {
      this.$refs.form.validate(valid => {
        if (valid) {
          if (this.selectedRow.length === 0) {
            this.$message.error('请勾选测试用例')
          }
          const scriptidsArr = new Array((this.selectedRow || []).map(item => item.scriptid))
          const scriptids = scriptidsArr.join(',')
          const taskName = this.formData.taskName
          this.$http.get('http://127.0.0.1:8300/runTask?scriptids=' + scriptids + '&taskname=' + taskName).then(response => {
            if (response.status === 200) {
              this.$message({
                message: response.data.update_desc,
                type: 'success',
                duration: 1500,
                onClose: () => {
                  this.visible = false
                  this.addOrUpdateStatus = false
                  this.$emit('refreshTcList')
                }
              })
            } else {
              this.$message.error('update error')
            }
          }, response => {
            // error callback
            this.$message.error('http error')
          })
        }
      })
    },
    closeModal () {
      this.visible = false
    },
    resetForm () {
      this.$refs.form.resetFields()
      this.formData = {
        taskName: ''
      }
    }
  }
}
</script>

<style scoped>

</style>
