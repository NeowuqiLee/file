// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store/Store'
import ElementUI from 'element-ui' // element-ui的全部组件
import 'element-ui/lib/theme-chalk/index.css'// element-ui的css
import Router from 'vue-router'
import VueResource from 'vue-resource'

Vue.use(VueResource)
Vue.use(Router) // 引入路由
Vue.use(ElementUI) // 使用elementUI

Vue.config.productionTip = false
Vue.http.options.emulateJSON = true// 解决跨域时 cors 检测发起的 option 请求

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>'
})
