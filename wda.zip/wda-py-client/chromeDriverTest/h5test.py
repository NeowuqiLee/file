# coding=utf-8
#from fastAutoTest.core.h5.h5Engine import H5Driver
from uiautomator import device as d
from fastAutoTest.core.h5.h5CommandManager import H5CommandManager
from fastAutoTest.core.h5.h5Engine import H5Driver
from fastAutoTest.core.h5.h5PageOperator import H5PageOperator
from fastAutoTest.core.h5.h5UserAPI import ByType
from fastAutoTest.core.h5.h5UserAPI import ActionType
from fastAutoTest.core.h5.h5WebSocketDebugUrlFetcher import *
import time
import sys
import MySQLdb
import json
import re
import os
import urllib
import requests
import commands
import urllib2

'''
Created on 2018年07月26日

@author: ivyzyzhang

自动化测试qq/微信中彩公众号
'''



timeout=4.0
#scriptids="10002,10003,10004,10005,10006,10007,10008,10009,10010,10011,10012,10013,10014,10015,10016,10017,10018,10019,10020,10021,10022,10023,10024,10025,10026,10027,10028,10029,10030,10050,10051,10053,10055,10092,10096,10129,10135,10141,10254,10386,10387,10481"
#scriptids='20002'
#scriptid='20005'
#taskid='417' #调用runsingle时要把这里注释掉
class DBO(object):
    def __init__(self):#__init__方法的第一参数永远是self，表示创建的类实例本身
        dbconfig = {#连接数据库
            'host': '10.12.91.190',
            'port': 3306,
            'user': 'root',
            'passwd': 'root203',
            'db': 'mobiletest',
            'charset': 'utf8'
        }

        self.conn = MySQLdb.connect(**dbconfig) ##建立数据库连接第一步 数据库和Navicat for mysql连接
        self.cursor = self.conn.cursor()#建立数据库连接第二步
        #         self.conn.set_character_set('utf8')
        #         self.cursor.execute('SET NAMES utf8;')
        #         self.cursor.execute('SET CHARACTER SET utf8;')
        #         self.cursor.execute('SET character_set_connection=utf8;')
        self.s = None

    def __close__(self):
            self.conn.close()

    def set_step_result(self,step):
        step_name = step['element_name']  # 用例名称
        value = step['find_method_value']  # xpath映射值
        map_key = value.encode("utf-8")  # 由于该value值为中文

        step_result = {'stepresult': '', 'stepname': '', 'uielement': '', 'timestamp': ''}
        step_result['uielement'] = map_key
        step_result['stepname'] = step_name
        now = int(time.time())
        step_result['timestamp'] = now

        return step_result

    def run_test_case(self, scriptid, taskid):

        #d(text="微信").click()
        #d(text="通讯录").click()
        #d(text="公众号").click()
        #d(text="天天中彩票").click()

        #从支付页面返回到初始页面
        while d(text='服务大厅').exists == False:
            d(className='android.widget.ImageView').click()

        d(text="服务大厅").click()# 进入服务大厅后，即H5页面
        print '打开中彩公众号H5首页成功'

        h5Driver = H5Driver()
        h5Driver.initDriver()
#        print '开始执行task %s scriptid %s ' % (taskid, scriptid)
#        print '开始执行task %s scriptid %s ' % (taskid, scriptid)
        sql_runing = "UPDATE `wda_ios_result` SET state='执行中' WHERE caseid='%s' AND taskid='%s' " % ('scriptid', 'taskid')
        print sql_runing
        self.cursor = self.conn.cursor()
        self.cursor.execute(sql_runing)
        self.conn.commit() #提交更改的数据给数据库

        run_state = '失败'
        run_ret = -1
        step_results = []
        success = 'success'
        fail = 'fail'

        step_result = {} #一个数组
        step_result['stepresult'] = success  #数组的每项元素
        step_result['stepname'] = u'点击服务大厅'
        step_result['uielement'] = u'点击服务大厅'
        now = int(time.time())#获得当前时间时间戳
        step_result['timestamp'] = now
        step_results.append(step_result)#添加到二维数组

        # h5Driver.clickElementByXpath('/html/body/div/div[1]/div/main/article/section[6]/div/div[1]/figure[1]')

        sql = "SELECT * FROM `tb_testcase` WHERE scriptid=%s " % (scriptid)
        print sql
        self.cursor = self.conn.cursor()
        self.cursor.execute(sql)  # 使用连接对象获得一个cursor对象,接下来,我们会使用cursor提供的方法来进行工作. 执行上述选择语句
        # 获取所有记录列表
        rows = self.cursor.fetchall()  # 接收全部的返回结果行 是根据上一行self.cursor.execute(sql)得到的结果行 结果行在用例表tb_testcase
        for row in rows:  # for循环，在数据库表中从行开始遍历到rows

            creator = row[3]
            # 双色球，大乐透对应字段description
            model_name = row[4]  # model_name为row的第5个元素description
            if (model_name=='双色球'):
                model_name_xpath='/html/body/div/div[1]/div/main/article/section[6]/div/div[1]/figure[1]'#映射双色球与xpath
            if (model_name=='福彩3D'):
                model_name_xpath='/html/body/div/div[1]/div/main/article/section[6]/div/div[2]/p'#映射福彩3D与xpath
            if (model_name=='大神推荐'):
                model_name_xpath='/html/body/div/div[1]/div/main/article/section[6]/div/div[3]/figure[1]'
            # 用例描述,名称
            case_name = row[9] #scriptname字段，用例名称
            step_result = {'stepresult': '', 'stepname': '', 'uielement': '',
                           'timestamp': ''}  # 上面已经声明过了，为什么再写一遍？给step_results再增加一条数组
            #script_steps = json.loads(row[10])  # 将已编码的 JSON 字符串解码为 Python 对象
            #find_method_value = step['find_method_value'] #xpath

            # 公众号中彩首页是否存在
            if h5Driver.isElementExist(model_name_xpath) == True:
                # 点击双色球
                h5Driver.clickElementByXpath(model_name_xpath)
                step_result['stepresult'] = success
                step_result['stepname'] = model_name
                step_result['uielement'] = model_name
                now = int(time.time())
                step_result['timestamp'] = now
                step_results.append(step_result)
                time.sleep(timeout)

                pre_script_ids = row[6]
                # print type(pre_script_ids);
                # for id in pre_script_ids:

                # 用例步骤
                # script_steps=json.loads(row[10],encoding='utf-8')
                # print script_steps
                # 用例类型tag冒烟、回归
                script_tag = row[12]  ##################################################这个和表字段对应应该是row[11]
                # 工具类型WebDriverAgent
                tool_type = row[13]
                script_steps = json.loads(row[10])
                for step in script_steps:
                    time.sleep(timeout)
                    step_result = {'stepresult': '', 'stepname': '', 'uielement': '', 'timestamp': ''}
                    element_type = step['element_type']#web
                    step_name = step['element_name']#控件名称
                    # find_method=name,value,id
                    find_method = step['find_method']#xpath


                    value = step['find_method_value']#为xpath映射值，控件标识
                    #文本替换
                    map_translate = {"我知道了": "//*[@id=\"guide_ssq\"]/div/div[2]/div/div[2]/button", "随机一注": "//*[@id=\"choose_footer\"]/div/div/a[1]",\
                                     "下一步": "//*[@id=\"showtip\"]","立即付款": "//*[@id=\"sure_footer\"]/div[3]/div[1]/a","支付": "//*[@id=\"js_dialog_content\"]/div[2]/div[2]/button",\
                                     "返回": "android.widget.ImageView","追号加": "//*[@id=\"sure_footer\"]/div[2]/div[1]/label/a[2]","加倍加": "//*[@id=\"sure_footer\"]/div[2]/div[2]/label/a[2]", \
                                     "自选号码": "//*[@id=\"sz_sure_box\"]/div/div[1]/a[1]","机选五注": "//*[@id=\"sz_sure_box\"]/div/div[1]/a[2]","组三": "//*[@id=\"wfscroll\"]/div/a[2]", \
                                     "福彩下一步提示": "//*[@id=\"guide_fc3d\"]/div[2]/div[1]/div[2]/button","福彩我知道了": "//*[@id=\"guide_fc3d\"]/div[2]/div[2]/div[2]/button",\
                                     "福彩随机一注": "//*[@id=\"choose_footer\"]/div/div[2]/a[1]","福彩立即付款": "//*[@id=\"sure_footer\"]/div[2]/div[1]/a",\
                                     "福彩追号加": "//*[@id=\"sure_footer\"]/div[1]/div[1]/label/a[2]","福彩加倍加": "//*[@id=\"sure_footer\"]/div[1]/div[2]/label/a[2]",\
                                     "组六": "//*[@id=\"wfscroll\"]/div/a[3]","方案详情": "//*[@id=\"record-list\"]/li[1]/a/div[1]","查看方案记录": "//*[@id=\"xdContent\"]/a[2]","测试": "","测试": "","测试": "","测试": ""}######
                    map_key = value.encode("utf-8")  # 由于该value值为中文
                    #map_key = value
                    if (map_translate.has_key(map_key)):  # 找到符合map_translate的关键字并输出
                        tmp = map_translate.get(str(map_key))
                        value = unicode(tmp, "utf-8")
                        #value=tmp
                        print "【文案替换】 %s ==> %s" % (str(map_key), str(tmp))
                    print value #输出xpath
                    # print type(name)
                    ui_index = int(step['ui_index'])
                    action_parameter = step['action_parameter']
                    action_type = step['action_type']
                    action_timeout = step['action_timeout']
                    # timeouts=(float)(int(action_timeout))/10000.0

                    find_method = step['find_method'] #定位方式
                    if find_method == 'id':
                        continue
                    if action_type == 'swipeUp':
                        self.s.swipe_up_()
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = success
                        step_results.append(step_result)
                        continue
                    if action_type == 'Wait':
                        time.sleep(2.0)
                        continue

                    if action_type == 'ExistGoto':
                        if self.s(name=value).exists == True:
                            step_result = self.set_step_result(step)
                            step_result['stepresult'] = success
                            step_results.append(step_result)
                            run_state = '成功'
                            run_ret = 0
                            continue
                        else:
                            step_result = self.set_step_result(step)
                            step_result['stepresult'] = fail
                            step_results.append(step_result)
                            continue
                    if action_type == 'NotExistGoto':###弹出异常页面，阻止下一步骤
                        if h5Driver.isElementExist(value) == True:
                            h5Driver.clickElementByXpath(value)
                            step_result = self.set_step_result(step)
                            step_result['stepresult'] = success
                            step_results.append(step_result)
                            continue
                        else:
                            step_result = self.set_step_result(step)
                            step_result['stepresult'] = fail
                            step_results.append(step_result)
                            continue
                    if element_type == 'Native':
                        if d(className=value).exists == True:
                            if action_type == 'Click':
                                if ui_index == 0:
                                    d(className=value).click()
                                    step_result = self.set_step_result(step)
                                    step_result['stepresult'] = success
                                    step_results.append(step_result)
                                    continue
                                else:#以下目前不执行
                                    self.s(name=value, index=ui_index).tap()
                                    step_result = self.set_step_result(step)
                                    step_result['stepresult'] = success
                                    step_results.append(step_result)
                                    continue
                            elif action_type == 'isExist':
                                self.s(name=value, index=ui_index).tap()
                                step_result = self.set_step_result(step)
                                step_result['stepresult'] = success
                                step_results.append(step_result)
                                run_state = '成功'
                                run_ret = 0
                            else:
                                step_result = self.set_step_result(step)
                                step_result['stepresult'] = fail
                                step_results.append(step_result)
                        else:
                            step_result = self.set_step_result(step)
                            step_result['stepresult'] = fail
                            step_results.append(step_result)
                    # weex元素统一用value查找
                    elif element_type == 'weex':
                        if self.s(value=value).exists == True or self.s(name=value).exists == True:
                            if action_type == 'Click':
                                if ui_index == 0:
                                    self.s(name=value).tap()
                                    step_result = self.set_step_result(step)
                                    step_result['stepresult'] = success
                                    step_results.append(step_result)
                                    continue
                                else:
                                    self.s(name=value, index=ui_index).tap()
                                    step_result = self.set_step_result(step)
                                    step_result['stepresult'] = success
                                    step_results.append(step_result)
                                    continue
                            elif action_type == 'isExist':
                                self.s(name=value, index=ui_index).tap()
                                step_result = self.set_step_result(step)
                                step_result['stepresult'] = success
                                run_state = '成功'
                                run_ret = 0
                                step_results.append(step_result)
                            else:
                                step_result = self.set_step_result(step)
                                step_result['stepresult'] = fail
                                step_results.append(step_result)
                        else:
                            step_result = self.set_step_result(step)
                            step_result['stepresult'] = fail
                            step_results.append(step_result)
            ###扩展web类型
                    elif element_type == 'Web':
                        if h5Driver.isElementExist(value) == True:
                            if action_type == 'Click':
                                if ui_index == 0:#uiindex对web的判断应该没用，因为定位方式是xpath
                                    h5Driver.clickElementByXpath(value)
                                    step_result = self.set_step_result(step)
                                    step_result['stepresult'] = success
                                    step_results.append(step_result)
                                    continue
                                else:
                                    h5Driver.clickElementByXpath(value)
                                    step_result = self.set_step_result(step)
                                    step_result['stepresult'] = success
                                    step_results.append(step_result)
                                    continue
                            #isExist是定义的用例的终止状态，判断最终预期目标元素是否存在，可定义任何操作类型
                            elif action_type == 'isExist':
                                #self.s(name=value, index=ui_index).tap()
                                h5Driver.clickElementByXpath(value)
                                step_result = self.set_step_result(step)
                                step_result['stepresult'] = success
                                step_results.append(step_result)
                                run_state = '成功'
                                run_ret = 0
                            else:
                                step_result = self.set_step_result(step)
                                step_result['stepresult'] = fail
                                step_results.append(step_result)
                        else:
                            step_result = self.set_step_result(step)
                            step_result['stepresult'] = fail
                            step_results.append(step_result)
                    else:
                        # element not found
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = fail
                        step_results.append(step_result)

            else:
                step_result['stepresult'] = fail
                step_result['stepname'] = model_name
                step_result['uielement'] = model_name
                step_results.append(step_result)
                run_state = '失败'
                run_ret = -1

            # 截图
            time.sleep(timeout)  # 等待页面缓冲过来
            os.system("adb shell /system/bin/screencap -p /sdcard/tmp.png")  # 保存到SDCard
            os.system("adb pull /sdcard/tmp.png E:\\testPicture")  # （保存到电脑）
            os.rename('E:\\testPicture\\tmp.png', 'E:\\testPicture\\%s_%s.png' % (taskid, scriptid))

            result = {
                'ret': run_ret,
                'state': run_state,
                'detail': step_results,
                #'img': img_path,
                'casename': case_name
             }
            #print '用例【%s】执行结果---------【%s】' % (scriptid, run_state)
            time.sleep(timeout)
        # ret=json.dumps(result, ensure_ascii=False).encode('utf-8')
            return json.dumps(result)  # 将一个Python数据结构转换为JSON


    def runH5Test(self, scriptids):
        create_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        appversion = '微信公众号'
        taskname = '微信公众号用例-双色球、福彩3D下单'
        # 成功用例，用例总数  成功，失败，总数
        taskview = 'null,null,null'
        taskstate = '运行中'

        insert_task_sql = "INSERT INTO `wda_ios_task` (`appid`, `appname`, `appversion`, `createtime`, `creator`, `description`, `deviceinfo`,\
        `devicelist`, `iscovered`, `mailto`, `monkeyargs`, `ostype`, `projectid`, `projectname`, `reportpath`, `result`, `scriptid`, `taskfrom`, \
        `taskname`, `taskresult`, `taskstate`, `tasktype`, `umid`) VALUES ('001', 'com.tencent.name', '%s', '%s', 'ivyzyzhang', '任务task',\
         'HUAWEI P9 7.0', '10.10.86.68:8100', NULL, NULL, NULL, 'Android', '1', '天天中彩票', 'http://jats.code.com/app/wda/report/null', '0',\
        '%s', NULL, '%s', '%s', '%s', 'Android UI自动化测试', 'ivyzyzhang')" % ( appversion, create_time, scriptids,taskname, taskview, taskstate)
        # print  insert_sql
        self.cursor.execute("SET NAMES utf8")
        self.cursor.execute(insert_task_sql)
        self.conn.commit()
        taskid = self.cursor.lastrowid #最后插入行的主键ID

        if taskid is not None:
            scriptids_array = scriptids.split(",")
            case_num = len(scriptids_array)
            print '共执行 %s 个用例' % case_num
            success_num = 0
            fail_num = 0
            for scriptid in scriptids_array:
                insert_test_result_sql = "INSERT INTO `wda_ios_result` (`taskid`, `caseid` , `umid` ,`tooltype` ,`loginfo`,`result`,`state`) VALUES ('%s'," \
                " '%s' , 'ivyzyzhang', 'Chrome DevTools Protocol', 'android','-1','失败') " % (
                    taskid, scriptid)
                print insert_test_result_sql
                self.cursor.execute(insert_test_result_sql)
                self.conn.commit()
                print '插入task %s 成功' % taskid
            for scriptid in scriptids_array:
                start_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                result = self.run_test_case(scriptid, taskid)
                end_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                run_result = json.loads(result) #将一个JSON编码的字符串转换回一个Python数据结构
                tmp_detail = run_result.get('detail')#step_results
                # 中文入库(将step_results入库）
                detail = json.dumps(tmp_detail, ensure_ascii=False).encode('utf8') #将一个Python数据结构转换为JSON  禁用ascii编码，按utf-8编码
                step_info = unicode(detail, 'utf8')#step_results
                #step_info=json.dumps(tmp_detail, ensure_ascii=False).encode('utf8')
                ######
                #step_info.replace('="' , '=\"')
                #step_info.replace('"', '\\\"')
                '''
                temp_n = len(step_info);
                for temp1 in range(temp_n):
                    if step_info[temp1] == '=' and step_info[temp1 + 1] == '"':
                        step_info[temp1 + 1]='\"'
                        temp2=temp1+2
                        for temp2 in temp_n:
                            if step_info[temp2] == '"':
                                step_info[temp2] = '\"'
                                break
                    break
                 '''
                casename = run_result.get('casename')
                state = run_result.get('state')
                ret = run_result.get('ret')
                if ret == 0:
                    success_num += 1
                else:
                    fail_num += 1
                update_test_result_sql = "UPDATE `wda_ios_result` SET endtime='%s', result='%s', starttime='%s', stepinfo='%s', casename='%s', state='%s' WHERE taskid='%s' AND caseid='%s'" % (
                    end_time, ret, start_time, step_info, casename, state, taskid, scriptid)
                # MySQLd.escape_string(step_info)
                # print update_test_result_sql
                self.cursor.execute(update_test_result_sql)
                self.conn.commit()
                # result_id=self.cursor.lastrowid
                print '更新scriptid %s 成功' % scriptid

            taskview = '%s,%s,%s' % (success_num, fail_num, case_num)
            taskstate = '完成'
            reportpath = 'http://jats.code.com/app/wda/report/%s' % taskid
            update_task_sql = "UPDATE `wda_ios_task` SET taskresult='%s',taskstate='%s',reportpath='%s' where taskid='%s' " % (
                taskview, taskstate, reportpath, taskid)
            # print update_task_sql
            self.cursor.execute(update_task_sql)
            self.conn.commit()
            print '---------------更新task %s 成功--------------' % taskid

        else:
            print '插入任务失败'


if __name__ == '__main__':
    dbo = DBO()
#    dbo.run_test_case(20005,644)

