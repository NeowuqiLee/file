# -*- coding:utf-8 -*-
from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
from SocketServer import ThreadingMixIn
import urlparse, time
from chromeDriverTest.h5test import DBO
from chromeDriverTest.xcxTest import DB1
import threading


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        rs = urlparse.urlparse(self.path)  # 解析url格式，将url分为6个部分，返回一个包含6个字符串项目的元组：协议、位置、路径、参数、查询、片段。
        method_uri = rs.path
        method_name = method_uri[1:]  # 将method_uri的第2位到最后一位赋给method_name = runtest
        param = urlparse.parse_qs(rs.query)  # 获取urlparse分割后元祖中的某一项，query是？后字段：scriptid=20001&scriptname=点击双色球
        if (method_name == 'runTest'):
            dbo = DBO()
            scriptid = param['scriptid'][0]
            taskid = 0
            result = dbo.run_test_case(scriptid, taskid)
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            print result
            self.wfile.write(result)

        elif (method_name == 'runH5Test' ):
            dbo = DBO()
            scriptids = param['scriptids'][0]
            dbo.runH5Test(scriptids)
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()

        elif (method_name == 'runXcxTest'):
            dbo = DB1()
            scriptids = param['scriptids'][0]
            dbo.runXcxTest(scriptids)
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()

        else:
            print 'function not found'

        #


# class test():
#     key = "key"
#     secret = "aaaa"
#     url = "http://127.0.0.1:8080/data?key="+key+"&secret="+secret.format(key=key, secret=secret)
#     print(url)
#     rs = urlparse.urlparse(url)
#     q = urlparse.parse_qs(rs.query)
#     print q
326


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """Handle requests in a separate thread."""


class MyThread(threading.Thread):
    def __init__(self, name):
        threading.Thread.__init__(self, name=name)

    def run(self):
        while True:
            dbo = DBO()
            print 'i am son thread,running handle'
            # dbo.run_daily_case()
            time.sleep(300)


if __name__ == '__main__':
    th = MyThread('handle')
    th.setDaemon(True)
    th.start()
    print 'http server started'
    server = ThreadedHTTPServer(('', 8200), Handler)
    server.serve_forever()





