# -*- coding: UTF-8 -*-

import os, json, csv, codecs
import numpy as np
from tempfile import mkstemp
from shutil import move
from os import remove, close

# reload(sys)
# sys.setdefaultencoding('utf8')

dir_path = '/Users/liwuqi/Downloads/beeline_ios/react-native-bak/'


def get_file_module(keyword):
    find_cmd = "cd  " + dir_path + " && find . -name " + keyword + " > " + keyword + ".txt"
    print (find_cmd)
    os.system(find_cmd)
    txt_path = dir_path + "/" + keyword + ".txt"
    fo_txt = open(txt_path, "r")
    modules = list()
    for line in open(txt_path):
        line = fo_txt.readline()
        # print line
        '''
        readline返回如下
        ./MMO/i18n/en.js
        ./Mine/i18n/en.js
        截断前面2个字符 ./，查找后面以/结尾
        '''
        index = line[2:].find('/')
        modules.append(line[2:2 + index])
    # 去重
    modules = list(set(modules))
    return modules


def get_js_file_path():
    txt_path = dir_path + "js.txt"
    if os.path.exists(txt_path):
        delete_cmd = "rm -f " + txt_path
        os.system(delete_cmd)
    find_cmd = "cd  " + dir_path + " && find . -name \*.js >>js.txt"
    os.system(find_cmd)
    find_cmd1 = "cd  " + dir_path + " && find . -name \*.tsx >>js.txt"
    os.system(find_cmd1)
    js_file_paths = []
    with open(txt_path, 'r') as f:
        for line in f:
            if line.find('node_modules') == -1:
                path = dir_path + line[2:-1]
                js_file_paths.append(path)
    return js_file_paths


def replace(file_paths):
    testids = np.random.randint(2000, size=2000).tolist()
    textinput = "<TextInput"
    text = "<Text"
    textStyle = "<TextStyle"
    textWidthComponent = "<TextWidthComponent"
    textAncestor = "<TextAncestor"
    textWidthProps = "<TextWidthProps"
    touchableWithoutFeedback="<TouchableWithoutFeedback"

    count = 0
    countNomatch = 0
    for path in file_paths:
        if os.path.exists(path):
            fh, abs_path = mkstemp()
            with open(abs_path, 'w') as new_file:
                with open(path) as old_file:
                    for line in old_file:
                        newline = line
                        if line.find(textStyle) != -1:
                            countNomatch=countNomatch+1
                            new_file.write(newline)
                            continue
                        if line.find(textWidthComponent) != -1:
                            countNomatch = countNomatch + 1
                            new_file.write(newline)
                            continue
                        if line.find(textAncestor) != -1:
                            countNomatch = countNomatch + 1
                            new_file.write(newline)
                            continue
                        if line.find(textAncestor) != -1:
                            countNomatch = countNomatch + 1
                            new_file.write(newline)
                            continue
                        if line.find(textWidthProps) != -1:
                            countNomatch = countNomatch + 1
                            new_file.write(newline)
                            continue
                        if line.find(textinput) != -1:
                            id = "textInputID" + str(testids.pop())
                            new_text = "<TextInput testID='%s' " % id
                            newline = line.replace(textinput, new_text)
                            count=count+1
                            #print "-------%s" % newline
                        elif line.find(text) != -1:
                            id = "textID" + str(testids.pop())
                            new_text = "<Text testID='%s' " % id
                            newline = line.replace(text, new_text)
                            count=count+1
                            #print newline
                        elif line.find(touchableWithoutFeedback) != -1:
                            id = "textID" + str(testids.pop())
                            new_text = "<TouchableWithoutFeedback testID='%s' " % id
                            newline = line.replace(text, new_text)
                            count = count + 1
                            # print newline
                        new_file.write(newline)

            close(fh)
            # Remove original file
            remove(path)
            # Move new file
            move(abs_path, path)



def readLineFromFile(modules):
    language_type = ['en', 'zh-Hant', 'zh']
    csv_results = {}
    # 遍历某个目录下语言包文件
    for module in modules:
         print (module)
    js_parent_path = dir_path + "/" + module + "/i18n/"
    if module == 'i18n':
        js_parent_path = dir_path + "/i18n/"
    # #测试专用js_parent_path = dir_path + "/OpenAccount/i18n"
    # 读取每个js文件
    for language in language_type:
        js_file_path = js_parent_path + "/" + language + ".js"
    if os.path.exists(js_file_path):
        fo_js = open(js_file_path, "r")
        for line in open(js_file_path):
            value = {"en": "", "zh-Hant": "", "zh": "", "module": module}
            line = fo_js.readline()
            # line.encode(encoding="utf-8", errors="strict")
            # print line
            '''
                           readline返回如下
                           common_delete: '删除',
                           common_file_too_big: '文件大小超过限制',
                           要排除*和/开头的注释行
                           '''
            if line.startswith("/"):
                continue
            if line.startswith("  //"):
                continue
            if line.startswith(" *"):
                continue
            if line.startswith("*"):
                continue
            # 冒号位置
            if line.find(":") == -1:
                continue

            # 查找到key
            key = line[2:line.find(":")]

            # 中英文简体翻译内容,兼容尾部没有逗号情况
            content = line[line.find(":") + 3:-2]

            # if key == "login_qrcode_input_tip":
            if content.endswith("'"):
                content = content[:-1]

            # result记录中已存在key
            # if key == "login_qrcode_input_tip":
            if csv_results.get(key) is None:
                csv_results[key] = value
        else:
            print ('')
    for module in modules:
        js_parent_path = dir_path + "/" + module + "/i18n/"
        if module == 'i18n':
            js_parent_path = dir_path + "/i18n/"
        # #测试专用js_parent_path = dir_path + "/OpenAccount/i18n"
        # 读取每个js文件
        for language in language_type:
            js_file_path = js_parent_path + "/" + language + ".js"
            if os.path.exists(js_file_path):
                fo_js = open(js_file_path, "r")
                for line in open(js_file_path):
                    line = fo_js.readline()
                    # line.encode(encoding="utf-8", errors="strict")
                    # print line
                    '''
                    readline返回如下
                    common_delete: '删除',
                    common_file_too_big: '文件大小超过限制',
                    要排除*和/开头的注释行
                    '''
                    if line.startswith("/"):
                        continue
                    if line.startswith("  //"):
                        continue
                    if line.startswith(" *"):
                        continue
                    if line.startswith("*"):
                        continue
                    # 冒号位置
                    if line.find(":") == -1:
                        continue

                    # 查找到key
                    key = line[2:line.find(":")]

                    # 中英文简体翻译内容,兼容尾部没有逗号情况
                    content = line[line.find(":") + 3:-2]

                    # if key == "login_qrcode_input_tip":
                    if content.endswith("'"):
                        content = content[:-1]

                    csv_results[key][language] = content
            else:
                print (js_file_path)
    return (csv_results)


# print json.dumps(csv_results, ensure_ascii=False).encode('utf-8')


def json2csv(data):
    csv_path = dir_path + '/multi-language.csv'
    # 清除上一次生成记录
    if os.path.exists(csv_path):
        delete_cmd = "rm -f " + csv_path
        os.system(delete_cmd)

    fo = file(csv_path, 'wb')
    fo.write(codecs.BOM_UTF8)
    csvwriter = csv.writer(fo)
    csvwriter.writerow(["key", "module", "zh", "zh-Hant", "en"])
    csv_data = list()
    for key, val in data.items():
        row = list()
        row.append(key)
        row.append(val['module'])
        row.append(val['zh'])
        row.append(val['zh-Hant'])
        row.append(val['en'])
        csv_data.append(row)
    # 简单排序，方便查看
    csv_data.sort()
    for row in csv_data:
        csvwriter.writerow(row)
    print (len(csv_data))
    fo.close()

    open_cmd = "open " + csv_path
    os.system(open_cmd)


if __name__ == '__main__':
    # keyword = 'zh.js'
    # modules = get_file_module(keyword)
    # data = readLineFromFile(modules)
    # json2csv(data)
    path = get_js_file_path()
    replace(path)
