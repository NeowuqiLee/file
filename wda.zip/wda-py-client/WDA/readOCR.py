# -*- coding: UTF-8 -*-

import json
if __name__ == '__main__':
    with open('/Users/liwuqi/Downloads/8-15.json','r') as f:
        load_dict=json.loads(f.read())
        change_count = 0
        print len(load_dict['RECORDS'])
        for i in load_dict['RECORDS']:
            if int(i['m_last_name'])|int(i['m_first_name'])|int(i['m_birthday'])|int(i['m_id_no']) == 1:
                change_count= change_count +1
        no_change_count=len(load_dict['RECORDS'])-change_count
        print no_change_count
        ocr_corret= no_change_count*1.00/len(load_dict['RECORDS'])
        print ocr_corret
