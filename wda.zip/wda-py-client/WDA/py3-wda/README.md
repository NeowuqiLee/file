## 安装依赖
pip install requirements.txt
## 说明文档
1、python engine_server启动 http 服务监听
2、调试用例
执行用例 curl http://127.0.0.1:8200/run_test_case?scriptid=17
执行任务 curl http://127.0.0.1:8200/run_task_case?scriptids=16&taskname="贷款测试"

## 更新日志
