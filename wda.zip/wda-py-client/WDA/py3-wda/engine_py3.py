# -*- coding: utf-8 -*-

import json
import os
import time
import pymysql
import wda

bundle_id = 'com.zhonganio.zabank'
#bundle_id = 'group.za.bank'
wda.DEBUG = False
c = wda.Client()
timeout = 5.0


# import sys
# reload(sys)
# sys.setdefaultencoding('utf8')


class Engine(object):
    def __init__(self):
        dbconfig = {
            'host': '172.16.3.183',
            'port': 8639,
            'user': 'app',
            'passwd': 'ZAppsit!!2018',
            'db': 'mobiletest',
            'charset': 'utf8'
        }

        self.conn = pymysql.connect(**dbconfig)
        self.cursor = self.conn.cursor()
        #         self.conn.set_character_set('utf8')
        #         self.cursor.execute('SET NAMES utf8;')
        #         self.cursor.execute('SET CHARACTER SET utf8;')
        #         self.cursor.execute('SET character_set_connection=utf8;')
        self.s = None

    def __close__(self):
        self.conn.close()

    def get_login_step(self):
        sql = "SELECT * FROM `tb_testcase` WHERE scriptid=1 "
        self.cursor = self.conn.cursor()
        self.cursor.execute(sql)
        # 获取所有记录列表
        rows = self.cursor.fetchall()
        for row in rows:
            login_steps = json.loads(row[10])
            return login_steps

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~用例执行函数~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def run_test_case(self, scriptid, taskid):
        str= '开始执行task %s scriptid %s ' % (taskid, scriptid)
        print(str)
        sql_runing = "UPDATE `wda_ios_result` SET state='执行中' WHERE caseid='%s' AND taskid='%s' " % (
            scriptid, taskid)
        # print sql_runing
        self.cursor = self.conn.cursor()
        self.cursor.execute(sql_runing)
        self.conn.commit()

        run_state = '失败'
        run_ret = -1
        step_results = []
        success = 'success'
        fail = 'fail'
        self.s = c.session(bundle_id)

        # 标记启动 app，做性能分析测试

        step_launch_result = {
            'stepresult': success,
            'stepname': '启动 app',
            'uielement': '众安银行',
            'timestamp': int(time.time())
        }
        step_results.append(step_launch_result)

        # 应用启动后等待初始化
        time.sleep(10)

        sql = "SELECT * FROM `tb_testcase` WHERE scriptid=%s " % (scriptid)
        # print sql
        self.cursor = self.conn.cursor()
        self.cursor.execute(sql)
        # 获取所有记录列表
        rows = self.cursor.fetchall()
        for row in rows:
            # wuqili
            creator = row[3]
            # 对应字段description,
            model_name = row[4]
            # 用例名称script_name
            case_name = row[9]

            # 拼接
            script_steps = self.get_login_step() + json.loads(row[10])

            # print script_steps
            # 用例类型tag冒烟、回归
            # script_tag = row[12]
            # 工具类型WebDriverAgent
            # tool_type = row[13]

            for step in script_steps:
                '''
                element_type = step['element_type']
                step_name = step['element_name']
                find_method = step['find_method']
                action_timeout = step['action_timeout']
                timeouts=(float)(int(action_timeout))/10000.0
                find_method = step['find_method']
                '''

                value = step['find_method_value']
                action_type = step['action_type']

                dir = '/Users/liwuqi/Downloads/screenshot/%s' % taskid
                if not os.path.exists(dir):
                    os.makedirs(dir)
                img_path = '/Users/liwuqi/Downloads/screenshot/%s/%s-%s.png' % (
                    taskid, scriptid, value.encode('utf8'))

                ui_index = int(step['ui_index'])
                action_parameter = step['action_parameter']

                if self.s(name=value).exists:
                    str= "element %s name found " % value.encode('utf8')
                    print(str)
                    if action_type == 'click':
                        self.s(name=value, index=ui_index).tap()
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = success
                        step_results.append(step_result)
                    elif action_type == 'isExist':
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = success
                        step_results.append(step_result)
                        run_state = '成功'
                        run_ret = 0
                    else:
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = fail
                        step_results.append(step_result)
                elif self.s(id=value).exists:
                    str= "element %s id found " % value.encode('utf8')
                    print(str)
                    if action_type == 'click':
                        self.s(id=value, index=ui_index).tap()
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = success
                        step_results.append(step_result)
                    elif action_type == 'isExist':
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = success
                        step_results.append(step_result)
                        run_state = '成功'
                        run_ret = 0
                    else:
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = fail
                        step_results.append(step_result)
                elif self.s(nameContains=value).exists:
                    str= "element %s nameContains found " % value.encode(
                        'utf8')
                    print(str)
                    if action_type == 'click':
                        self.s(nameContains=value, index=ui_index).tap()
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = success
                        step_results.append(step_result)
                    elif action_type == 'isExist':
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = success
                        step_results.append(step_result)
                        run_state = '成功'
                        run_ret = 0
                    else:
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = fail
                        step_results.append(step_result)
                # 参数不为空时需要单独判断
                elif action_parameter != '':
                    coordinate_parameter_str = action_parameter.encode('utf8')
                    coordinate = coordinate_parameter_str.split(",")
                    if action_type == 'click':
                        self.s.tap(coordinate[0], coordinate[1])
                        str= '元素 %s --> 点击坐标(%s,%s)' % (
                            value.encode('utf8'), coordinate[0], coordinate[1])
                        print(str)
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = success
                        step_results.append(step_result)
                    elif action_type == 'isExist' and coordinate_parameter_str == "true":
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = success
                        step_results.append(step_result)
                        run_state = '成功'
                        run_ret = 0

                    elif action_type == "setText":
                        text = action_parameter.encode('utf8')
                        self.s.send_keys(text)

                elif action_type == "swipeUp":
                    if value == "swipe_to_bottom":
                        for i in range(20):
                            self.s.swipe(180, 520, 180, 0)
                            print ("swipe up")
                    else:
                        self.s.swipe_up()
                elif action_type == "swipeDown":
                    self.s.swipe_down()
                elif action_type == "swipeLeft":
                    self.s.swipe_left()
                elif action_type == "swipeRight":
                    self.s.swipe_right()
                elif action_type == "wait":
                    time.sleep(timeout)

                else:
                    str="element %s 404!!! " % value.encode('utf8')
                    print(str)
                    step_result = self.set_step_result(step)
                    step_result['stepresult'] = fail
                    step_results.append(step_result)

                # 运行后截图
                time.sleep(timeout)
                c.screenshot(img_path)

            result = {
                'ret': run_ret,
                'state': run_state,
                'detail': step_results,
                'casename': case_name
            }
            str= '用例【%s】执行结果---------【%s】' % (scriptid, run_state)
            print(str)
            if run_ret == 0:
                # 把用例更新为调试状态，通过
                update_test_case = "UPDATE `tb_testcase` SET projectid='1' where scriptid='%s' " % (scriptid)
                # print  update_test_case
                self.cursor.execute(update_test_case)
                self.conn.commit()
            return json.dumps(result)

    def set_step_result(self, step):
        step_result = {
            'stepresult': '',
            'stepname': '',
            'uielement': '',
            'timestamp': ''
        }
        step_result['uielement'] = step['find_method_value']  # 查找元素值
        step_result['stepname'] = step['element_name']  # 用例描述
        step_result['timestamp'] = int(time.time())  # 记录时间
        return step_result

    def run_task_case(self, scriptids, taskname):
        create_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        appversion = '1.0.5'
        # taskname= 'zabank-定期存款100'
        # 成功用例，用例总数  成功，失败，总数
        taskview = 'null,null,null'
        taskstate = '运行中'

        insert_task_sql = "INSERT INTO `wda_ios_task` (`appid`, `appname`, `appversion`, `createtime`, `creator`, `description`, `deviceinfo`, `devicelist`, `iscovered`, `mailto`, `monkeyargs`, `ostype`, `projectid`, `projectname`, `reportpath`, `result`, `scriptid`, `taskfrom`, `taskname`, `taskresult`, `taskstate`, `tasktype`, `umid`) VALUES ('001', 'com.zhonganio.zabank', '%s', '%s', 'wuqili', '任务task', 'iPhone 8-iOS12.4.1\n', '172.16.232.79:8100', NULL, NULL, NULL, 'iOS', '1', 'zabank', '', '0', '%s', '172.16.233.23', '%s', '%s', '%s', 'iOS UI自动化测试', 'wuqili')" % (
            appversion, create_time, scriptids, taskname, taskview, taskstate)
        # print  insert_sql
        self.cursor.execute("SET NAMES utf8")
        self.cursor.execute(insert_task_sql)
        self.conn.commit()
        taskid = self.cursor.lastrowid

        if taskid is not None:
            scriptids_array = scriptids.split(",")
            case_num = len(scriptids_array)
            str= '共执行 %s 个用例' % case_num
            print(str)
            success_num = 0
            fail_num = 0
            for scriptid in scriptids_array:
                insert_test_result_sql = "INSERT INTO `wda_ios_result` (`taskid`, `caseid` , `umid` ,`tooltype` ,`loginfo`,`result`,`state`) VALUES ('%s', '%s' , 'wuqili', 'webDriverAgent', 'iOS','-1','未执行') " % (
                    taskid, scriptid)
                print(insert_test_result_sql)
                self.cursor.execute(insert_test_result_sql)
                self.conn.commit()
            for scriptid in scriptids_array:
                start_time = time.strftime("%Y-%m-%d %H:%M:%S",
                                           time.localtime())
                result = self.run_test_case(scriptid, taskid)
                end_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                run_result = json.loads(result)
                tmp_detail = run_result.get('detail')
                # 中文入库
                detail = json.dumps(tmp_detail,
                                    ensure_ascii=False).encode('utf8')
                step_info = str(detail, 'utf8')
                casename = run_result.get('casename')
                state = run_result.get('state')
                ret = run_result.get('ret')
                if ret == 0:
                    success_num += 1
                else:
                    fail_num += 1
                update_test_result_sql = "UPDATE `wda_ios_result` SET endtime='%s', result='%s', starttime='%s', stepinfo='%s', casename='%s', state='%s' WHERE taskid='%s' AND caseid='%s'" % (
                    end_time, ret, start_time, step_info, casename, state,
                    taskid, scriptid)
                print (update_test_result_sql)
                self.cursor.execute(update_test_result_sql)
                self.conn.commit()

        taskview = '%s,%s,%s' % (success_num, fail_num, case_num)
        taskstate = '完成'
        reportpath = 'http://qam.in.za/#/uitest-test-task-list'
        update_task_sql = "UPDATE `wda_ios_task` SET taskresult='%s',taskstate='%s',reportpath='%s' where taskid='%s' " % (
            taskview, taskstate, reportpath, taskid)
        # print update_task_sql
        self.cursor.execute(update_task_sql)
        self.conn.commit()
        self.__close__()

def run_daily_case(self):
    scripts_dic = {}
    scripts = []
    sql = "SELECT scriptid, scriptname from `mobiletest`.`tb_testcase` WHERE ostype='iOS' AND tag='定存'"
    self.cursor.execute(sql)
    rows = self.cursor.fetchall()
    for row in rows:
        key = str(row[0])
        value = row[1].encode('utf8')
        scripts_dic[key] = value
        scripts.append(key)
    scriptids = ','.join(scripts)

    create_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    appversion = '1.0.5'
    taskname = '定期存款gamma监控用例'
    # 成功用例，用例总数  成功，失败，总数
    taskview = 'null,null,null'
    taskstate = '运行中'

    insert_task_sql = "INSERT INTO `wda_ios_task` (`appid`, `appname`, `appversion`, `createtime`, `creator`, `description`, `deviceinfo`, `devicelist`, `iscovered`, `mailto`, `monkeyargs`, `ostype`, `projectid`, `projectname`, `reportpath`, `result`, `scriptid`, `taskfrom`, `taskname`, `taskresult`, `taskstate`, `tasktype`, `umid`) VALUES ('001', 'com.zhonganio.zabank', '%s', '%s', 'wuqili', '任务task', 'iPhone 8-iOS12.4.1\n', '10.10.86.68:8100', NULL, NULL, NULL, 'iOS', '1', 'zabank', 'http://qam.in.za/#/uitest-test-task-list', '0', '%s', '172.16.233.23', '%s', '%s', '%s', 'iOS UI自动化测试', 'wuqili')" % (
        appversion, create_time, scriptids, taskname, taskview, taskstate)
    # print  insert_sql
    self.cursor.execute("SET NAMES utf8")
    self.cursor.execute(insert_task_sql)
    self.conn.commit()
    taskid = self.cursor.lastrowid

    if taskid is not None:
        scriptids_array = scriptids.split(",")
        case_num = len(scriptids_array)
        str= '共执行 %s 个用例' % case_num
        print(str)
        for key, value in scripts_dic.items():
            # 更新插入用例名称
            insert_test_result_sql = "INSERT INTO `wda_ios_result` (`taskid`, `caseid` , `umid` ,`tooltype` ,`loginfo`,`result`,`state`,`casename`) VALUES ('%s', '%s' , 'wuqili', 'webDriverAgent', 'iOS','-1','未执行','%s') " % (
                taskid, key, value)
            # print insert_test_result_sql
            self.cursor.execute(insert_test_result_sql)
            self.conn.commit()
        for scriptid in scriptids_array:

            # 重试总次数=3次
            fail_num = 2
            while fail_num:
                start_time = time.strftime("%Y-%m-%d %H:%M:%S",
                                           time.localtime())
                result = self.run_test_case(scriptid, taskid)
                end_time = time.strftime("%Y-%m-%d %H:%M:%S",
                                         time.localtime())
                run_result = json.loads(result)
                tmp_detail = run_result.get('detail')
                # 中文入库
                detail = json.dumps(tmp_detail,
                                    ensure_ascii=False).encode('utf8')
                step_info = str(detail, 'utf8')
                casename = run_result.get('casename')
                state = run_result.get('state')
                ret = run_result.get('ret')
                if ret == 0:
                    update_test_result_sql = "UPDATE `wda_ios_result` SET endtime='%s', result='%s', starttime='%s', stepinfo='%s', casename='%s', state='%s' WHERE taskid='%s' AND caseid='%s'" % (
                        end_time, ret, start_time, step_info, casename,
                        state, taskid, scriptid)
                    self.cursor.execute(update_test_result_sql)
                    self.conn.commit()
                    fail_num = 0
                    break
                else:
                    self.run_test_case(scriptid, taskid)
                    update_test_result_sql = "UPDATE `wda_ios_result` SET endtime='%s', result='%s', starttime='%s', stepinfo='%s', casename='%s', state='%s' WHERE taskid='%s' AND caseid='%s'" % (
                        end_time, ret, start_time, step_info, casename,
                        state, taskid, scriptid)
                    self.cursor.execute(update_test_result_sql)
                    self.conn.commit()
                    fail_num = fail_num - 1

        reportpath = 'http://qam.in.za/#/uitest-test-task-list'
        update_task_sql = "UPDATE `wda_ios_task` SET taskstate='完成',reportpath='%s' where taskid='%s' " % (
            reportpath, taskid)
        # print update_task_sql
        self.cursor.execute(update_task_sql)
        self.conn.commit()
        self.get_failed_case_num(taskid)
    else:
        print ("插入任务失败")


def retry_task_case(self, scriptid, taskid):
    start_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    result = self.run_test_case(scriptid, taskid)
    end_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    run_result = json.loads(result)
    tmp_detail = run_result.get('detail')
    # 中文入库
    detail = json.dumps(tmp_detail, ensure_ascii=False).encode('utf8')
    step_info = str(detail, 'utf8')
    casename = run_result.get('casename')
    state = run_result.get('state')
    ret = run_result.get('ret')
    # 用例重试成功
    if ret == 0:
        update_test_result_sql = "UPDATE `wda_ios_result` SET endtime='%s',result='%s',starttime='%s',stepinfo='%s',casename='%s',state='%s' WHERE taskid='%s' AND caseid='%s' " % (
            end_time, ret, start_time, step_info, casename, state, taskid,
            scriptid)
        # print update_test_result_sql
        self.cursor.execute(update_test_result_sql)
        self.conn.commit()
        str= '用例%s  重试成功' % scriptid
        print(str)
    else:
        update_test_result_sql = "UPDATE `wda_ios_result` SET endtime='%s',result='%s',starttime='%s',stepinfo='%s',casename='%s',state='%s' WHERE taskid='%s' AND caseid='%s' " % (
            end_time, ret, start_time, step_info, casename, state, taskid,
            scriptid)
        # print update_test_result_sql
        self.cursor.execute(update_test_result_sql)
        self.conn.commit()
        str= '用例%s  重试失败' % scriptid
        print(str)
    self.get_failed_case_num(taskid)


def retry_task_failed_case(self, scriptids, taskid):
    scriptids_array = scriptids.split(",")
    for scriptid in scriptids_array:
        self.retry_task_case(scriptid, taskid)
    self.get_failed_case_num(taskid)


def get_failed_case_num(self, taskid):
    # 计算用例总数
    sql_num = "SELECT count(1) FROM `wda_ios_result` WHERE taskid=%s " % (
        taskid)
    self.cursor = self.conn.cursor()
    self.cursor.execute(sql_num)
    rows = self.cursor.fetchall()
    case_num = ''
    for row in rows:
        case_num = row[0]
    # 计算成功用例总数
    sql_success_num = "SELECT count(1) FROM `wda_ios_result` WHERE taskid=%s AND state='成功'" % (
        taskid)
    self.cursor = self.conn.cursor()
    self.cursor.execute(sql_success_num)
    rows = self.cursor.fetchall()
    success_num = ''
    for row in rows:
        success_num = row[0]
    fail_num = int(case_num) - int(success_num)
    taskview = '%s,%s,%s' % (success_num, fail_num, case_num)
    taskstate = '完成'
    update_task_sql = "UPDATE `wda_ios_task` SET taskresult='%s',taskstate='%s' where taskid='%s' " % (
        taskview, taskstate, taskid)
    # print update_task_sql
    self.cursor.execute(update_task_sql)
    self.conn.commit()


##########################合并同一个文件夹下多个txt################
def merge_txt_file(filepath, outfile):
    k = open(filepath + outfile, 'a+')
    for parent, dirnames, filenames in os.walk(filepath):
        for filepath in filenames:
            txtPath = os.path.join(parent, filepath)  # txtpath就是所有文件夹的路径
            f = open(txtPath)
            ##########换行写入##################
            k.write(f.read() + "\n")

    k.close()


if __name__ == '__main__':
    engine = Engine()
