# -*- coding:utf-8 -*-

import threading
import time
import json
from urllib import parse
from http.server import BaseHTTPRequestHandler, HTTPServer
from .engine_py3 import Engine



class Wda_Engine_Server(BaseHTTPRequestHandler):
    def do_GET(self):
        rs = parse.urlparse(self.path)
        method_uri = rs.path
        method_name = method_uri[1:]

        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header("Access-Control-Allow-Headers", "X-Requested-With")
        self.send_header("Content-type", "application/json")
        self.end_headers()

        engine = Engine()

        param = parse.parse_qs(rs.query)
        if (method_name == 'run_test_case'):
            scriptid = param['scriptid'][0]
            taskid = 0
            result = engine.run_test_case(scriptid, taskid)
            self.wfile.write(result)

        elif (method_name == 'run_task_case'):
            scriptids = param['scriptids'][0]
            taskname = param['taskname'][0]
            result = engine.run_task_case(scriptids, taskname)
            self.wfile.write(result)

        elif (method_name == 'retry_task_case'):
            scriptid = param['scriptid'][0]
            taskid = param['taskid'][0]
            result = engine.retry_task_case(scriptid, taskid)
            self.wfile.write(result)

        elif (method_name == 'retry_task_failed_case'):
            scriptids = param['scriptids'][0]
            taskid = param['taskid'][0]
            result = engine.retry_task_failed_case(scriptids, taskid)
            self.wfile.write(result)

        elif (method_name == 'getTaskStatus'):
            taskid = param['taskid'][0]
            result = engine.get_task_status(taskid)
            self.wfile.write(result)
        elif (method_name == 'hello'):
            data = [{'method': 'hello'}]
            self.wfile.write(json.dumps(data))
        else:
            print('function not found')


class MyThread(threading.Thread):
    def __init__(self, name):
        threading.Thread.__init__(self, name=name)

    def run(self):
        while True:
            # engine().run_daily_case()
            print('i am son thread,running loop')
            time.sleep(3000)


if __name__ == '__main__':
    port = 8200
    print('starting server, port', port)
    server_address = ('', port)
    httpd = HTTPServer(server_address, Wda_Engine_Server)
    print('running server...')
    httpd.serve_forever()