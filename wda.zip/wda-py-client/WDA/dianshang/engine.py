# -*- coding: utf-8 -*-

import json
import os
import time
import pymysql
import wda

bundle_id = 'com.tencent.xin'
# bundle_id = 'group.za.bank'
wda.DEBUG = False
c = wda.Client()
timeout = 5.0


# import sys
# reload(sys)
# sys.setdefaultencoding('utf8')


class Engine(object):
    def __init__(self):
        dbconfig = {
            'host': '127.0.0.1',
            'port': 3306,
            'user': 'root',
            'passwd': '1qa2ws3ed',
            'db': 'mobiletest',
            'charset': 'utf8'
        }
        self.conn = pymysql.connect(**dbconfig)
        self.cursor = self.conn.cursor()
        #         self.conn.set_character_set('utf8')
        #         self.cursor.execute('SET NAMES utf8;')
        #         self.cursor.execute('SET CHARACTER SET utf8;')
        #         self.cursor.execute('SET character_set_connection=utf8;')
        self.s = None

    def __close__(self):
        self.conn.close()


    ##########################清空上次任务接口数据t################
    def rm_http_file(self):
        dir = "/Users/wuqili/Downloads/networklog/"
        if not os.path.exists(dir):
            os.makedirs(dir)
        else:
            cmd = "cd %s && rm -rf *" % dir
            os.system(cmd)
            print("清空接口文件txt 成功")
        ##########################获取任务执行的接口数据t################

    def merge_http_file(self):
        dir = "/Users/wuqili/Downloads/networklog/"
        dir_DS_Store = "/Users/wuqili/Downloads/networklog/.DS_Store"
        data = []
        for root, dirs, files in os.walk(dir):
            for file in files:
                # 获取文件所属目录
                # print(root)
                # 获取文件路径
                txt_path = os.path.join(root, file)
                if txt_path == dir_DS_Store:
                    continue
                print(txt_path)

                with open(txt_path, 'r') as f:
                    data_tmp = json.load(f)
                    # print data_tmp
                    data.append(data_tmp)
        return json.dumps(data)

    def get_login_step(self):
        sql = "SELECT * FROM `tb_testcase` WHERE scriptid=1 "
        self.cursor = self.conn.cursor()
        self.cursor.execute(sql)
        # 获取所有记录列表
        rows = self.cursor.fetchall()
        for row in rows:
            login_steps = json.loads(row[10])
            return login_steps

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~用例执行函数~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def run_test_case(self, scriptid, taskid):
        str = '开始执行task %s scriptid %s ' % (taskid, scriptid)
        print(str)
        sql_runing = "UPDATE `wda_ios_result` SET state='执行中' WHERE caseid='%s' AND taskid='%s' " % (
            scriptid, taskid)
        # print sql_runing
        self.cursor = self.conn.cursor()
        self.cursor.execute(sql_runing)
        self.conn.commit()

        run_state = '失败'
        run_ret = -1
        step_results = []
        success = 'success'
        fail = 'fail'
        self.s = c.session(bundle_id)

        # 应用启动后等待初始化
        time.sleep(10)

        sql = "SELECT * FROM `tb_testcase` WHERE scriptid=%s " % (scriptid)
        # print sql
        self.cursor = self.conn.cursor()
        self.cursor.execute(sql)
        # 获取所有记录列表
        rows = self.cursor.fetchall()
        for row in rows:
            # wuqili
            creator = row[3]
            # 对应字段description,
            model_name = row[4]
            # 用例名称script_name
            case_name = row[9]

            # 拼接
            script_steps = self.get_login_step() + json.loads(row[10])
            # script_steps = json.loads(row[10])

            # print script_steps
            # 用例类型tag冒烟、回归
            # script_tag = row[12]
            # 工具类型WebDriverAgent
            # tool_type = row[13]

            for step in script_steps:
                '''
                element_type = step['element_type']
                step_name = step['element_name']
                find_method = step['find_method']
                action_timeout = step['action_timeout']
                timeouts=(float)(int(action_timeout))/10000.0
                find_method = step['find_method']
                '''

                value = step['find_method_value']
                action_type = step['action_type']

                dir = '/Users/wuqili/Downloads/screenshot/%s' % taskid
                if not os.path.exists(dir):
                    os.makedirs(dir)
                img_path = '/Users/wuqili/Downloads/screenshot/%s/%s-%s.png' % (
                    taskid, scriptid, value)

                ui_index = int(step['ui_index'])
                action_parameter = ''
                if 'action_parameter' in step:
                    action_parameter = step['action_parameter']

                if self.s(name=value).exists:
                    print("element %s name found " % value)
                    if action_type == 'click':
                        self.s(name=value, index=ui_index).tap()
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = success
                        step_results.append(step_result)
                    elif action_type == 'isExist':
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = success
                        step_results.append(step_result)
                        run_state = '成功'
                        run_ret = 0
                    else:
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = fail
                        step_results.append(step_result)
                elif self.s(id=value).exists:
                    print("element %s name found " % value)
                    if action_type == 'click':
                        self.s(id=value, index=ui_index).tap()
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = success
                        step_results.append(step_result)
                    elif action_type == 'isExist':
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = success
                        step_results.append(step_result)
                        run_state = '成功'
                        run_ret = 0
                    else:
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = fail
                        step_results.append(step_result)
                elif self.s(nameContains=value).exists:
                    print("element %s name found " % value)
                    if action_type == 'click':
                        self.s(nameContains=value, index=ui_index).tap()
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = success
                        step_results.append(step_result)
                    elif action_type == 'isExist':
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = success
                        step_results.append(step_result)
                        run_state = '成功'
                        run_ret = 0
                    else:
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = fail
                        step_results.append(step_result)
                # 参数不为空时需要单独判断
                elif action_parameter != '':
                    coordinate = action_parameter.split(",")
                    if action_type == 'click':
                        self.s.tap(coordinate[0], coordinate[1])
                        print(('元素 %s --> 点击坐标(%s,%s)') % (
                            value, coordinate[0], coordinate[1]))
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = success
                        step_results.append(step_result)
                    elif action_type == 'isExist' and action_parameter == "true":
                        step_result = self.set_step_result(step)
                        step_result['stepresult'] = success
                        step_results.append(step_result)
                        run_state = '成功'
                        run_ret = 0

                    elif action_type == "setText":
                        self.s.send_keys(action_parameter)

                elif action_type == "swipeUp":
                    if value == "swipe_to_bottom":
                        for i in range(20):
                            self.s.swipe(180, 520, 180, 0)
                            print("swipe up")
                    else:
                        self.s.swipe_up()
                elif action_type == "swipeDown":
                    self.s.swipe_down()
                elif action_type == "swipeLeft":
                    self.s.swipe_left()
                elif action_type == "swipeRight":
                    self.s.swipe_right()
                elif action_type == "wait":
                    time.sleep(timeout)

                else:
                    print("element %s 404 " % value)
                    step_result = self.set_step_result(step)
                    step_result['stepresult'] = fail
                    step_results.append(step_result)

                # 运行后截图
                time.sleep(timeout)
                c.screenshot(img_path)

            result = {
                'ret': run_ret,
                'state': run_state,
                'detail': step_results,
                'casename': case_name
            }
            str = '用例【%s】执行结果---------【%s】' % (scriptid, run_state)
            print(str)
            if run_ret == 0:
                # 把用例更新为调试状态，通过
                update_test_case = "UPDATE `tb_testcase` SET projectid='1' where scriptid='%s' " % (scriptid)
                # print  update_test_case
                self.cursor.execute(update_test_case)
                self.conn.commit()
            return json.dumps(result)

    def set_step_result(self, step):
        step_result = {
            'stepresult': '',
            'stepname': '',
            'uielement': '',
            'timestamp': ''
        }
        step_result['uielement'] = str(step['find_method_value'])  # 查找元素值
        step_result['stepname'] = str(step['element_name'])  # 用例描述
        step_result['timestamp'] = int(time.time())  # 记录时间
        return step_result

    def run_task_case(self, scriptids, taskname):
        self.rm_http_file()
        create_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        appversion = '1.0.0'
        # 成功用例，用例总数  成功，失败，总数
        taskview = 'null,null,null'
        taskstate = '运行中'

        insert_task_sql = "INSERT INTO `wda_ios_task` (`appid`, `appname`, `appversion`, `createtime`, `creator`, `description`, `deviceinfo`, `devicelist`, `iscovered`, `mailto`, `monkeyargs`, `ostype`, `projectid`, `projectname`, `reportpath`, `result`, `scriptid`, `taskfrom`, `taskname`, `taskresult`, `taskstate`, `tasktype`, `umid`) VALUES ('001', 'com.tencent.xin', '%s', '%s', 'wuqili', '任务task', 'iPhone 7 Plus-iOS13.1\n', '172.16.232.79:8100', NULL, NULL, NULL, 'iOS', '1', '电商小程序', '', '0', '%s', '172.16.233.23', '%s', '%s', '%s', 'iOS UI自动化测试', 'wuqili')" % (
            appversion, create_time, scriptids, taskname, taskview, taskstate)
        # print  insert_sql
        self.cursor.execute("SET NAMES utf8")
        self.cursor.execute(insert_task_sql)
        self.conn.commit()
        taskid = self.cursor.lastrowid

        if taskid is not None:
            scriptids_array = scriptids.split(",")
            case_num = len(scriptids_array)
            str = '共执行 %s 个用例' % case_num
            print(str)
            success_num = 0
            fail_num = 0
            for scriptid in scriptids_array:
                insert_test_result_sql = "INSERT INTO `wda_ios_result` (`taskid`, `caseid` , `umid` ,`tooltype` ,`loginfo`,`result`,`state`) VALUES ('%s', '%s' , 'wuqili', 'webDriverAgent', 'iOS','-1','未执行') " % (
                    taskid, scriptid)
                print(insert_test_result_sql)
                self.cursor.execute(insert_test_result_sql)
                self.conn.commit()
                str = '插入task %s 成功' % taskid
                print(str)
            for scriptid in scriptids_array:
                start_time = time.strftime("%Y-%m-%d %H:%M:%S",
                                           time.localtime())
                result = self.run_test_case(scriptid, taskid)
                end_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                run_result = json.loads(result)
                step_info = json.dumps(run_result.get('detail'), ensure_ascii=False)
                casename = run_result.get('casename')
                state = run_result.get('state')
                ret = run_result.get('ret')
                if ret == 0:
                    success_num += 1
                else:
                    fail_num += 1
                update_test_result_sql = "UPDATE `wda_ios_result` SET endtime='%s', result='%s', starttime='%s', stepinfo='%s', casename='%s', state='%s' WHERE taskid='%s' AND caseid='%s'" % (
                    end_time, ret, start_time, step_info, casename, state,
                    taskid, scriptid)
                print(update_test_result_sql)
                self.cursor.execute("SET NAMES utf8")
                self.cursor.execute(update_test_result_sql)
                self.conn.commit()

        taskview = '%s,%s,%s' % (success_num, fail_num, case_num)
        taskstate = '完成'

        #等待whistle异步写入http数据结束
        time.sleep(10)

        devicelist= self.merge_http_file()
        update_task_sql = "UPDATE `wda_ios_task` SET taskresult='%s',taskstate='%s',devicelist='%s' where taskid='%s' " % (
            taskview, taskstate, devicelist, taskid)
        # print update_task_sql
        self.cursor.execute("SET NAMES utf8")
        self.cursor.execute(update_task_sql)
        self.conn.commit()
        self.__close__()
        str = '---------------更新task %s 成功--------------' % taskid
        print(str)


def run_daily_case(self):
    scripts_dic = {}
    scripts = []
    sql = "SELECT scriptid, scriptname from `mobiletest`.`tb_testcase` WHERE ostype='iOS' AND tag='定存'"
    self.cursor.execute(sql)
    rows = self.cursor.fetchall()
    for row in rows:
        key = str(row[0])
        value = row[1].encode('utf8')
        scripts_dic[key] = value
        scripts.append(key)
    scriptids = ','.join(scripts)

    create_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    appversion = '1.0.0'
    taskname = '定期存款gamma监控用例'
    # 成功用例，用例总数  成功，失败，总数
    taskview = 'null,null,null'
    taskstate = '运行中'

    insert_task_sql = "INSERT INTO `wda_ios_task` (`appid`, `appname`, `appversion`, `createtime`, `creator`, `description`, `deviceinfo`, `devicelist`, `iscovered`, `mailto`, `monkeyargs`, `ostype`, `projectid`, `projectname`, `reportpath`, `result`, `scriptid`, `taskfrom`, `taskname`, `taskresult`, `taskstate`, `tasktype`, `umid`) VALUES ('001', 'com.tencent.xin', '%s', '%s', 'wuqili', '任务task', 'iPhone 7 Plus-iOS13.1\n', '10.10.86.68:8100', NULL, NULL, NULL, 'iOS', '1', '电商小程序', 'http://qam.in.za/#/uitest-test-task-list', '0', '%s', '172.16.233.23', '%s', '%s', '%s', 'iOS UI自动化测试', 'wuqili')" % (
        appversion, create_time, scriptids, taskname, taskview, taskstate)
    # print  insert_sql
    self.cursor.execute("SET NAMES utf8")
    self.cursor.execute(insert_task_sql)
    self.conn.commit()
    taskid = self.cursor.lastrowid

    if taskid is not None:
        scriptids_array = scriptids.split(",")
        case_num = len(scriptids_array)
        str = '共执行 %s 个用例' % case_num
        print(str)
        for key, value in scripts_dic.items():
            # 更新插入用例名称
            insert_test_result_sql = "INSERT INTO `wda_ios_result` (`taskid`, `caseid` , `umid` ,`tooltype` ,`loginfo`,`result`,`state`,`casename`) VALUES ('%s', '%s' , 'wuqili', 'webDriverAgent', 'iOS','-1','未执行','%s') " % (
                taskid, key, value)
            # print insert_test_result_sql
            self.cursor.execute(insert_test_result_sql)
            self.conn.commit()
        for scriptid in scriptids_array:

            # 重试总次数=3次
            fail_num = 2
            while fail_num:
                start_time = time.strftime("%Y-%m-%d %H:%M:%S",
                                           time.localtime())
                result = self.run_test_case(scriptid, taskid)
                end_time = time.strftime("%Y-%m-%d %H:%M:%S",
                                         time.localtime())
                run_result = json.loads(result)
                step_info = json.dumps(run_result.get('detail'), ensure_ascii=False)
                casename = run_result.get('casename')
                state = run_result.get('state')
                ret = run_result.get('ret')
                if ret == 0:
                    update_test_result_sql = "UPDATE `wda_ios_result` SET endtime='%s', result='%s', starttime='%s', stepinfo='%s', casename='%s', state='%s' WHERE taskid='%s' AND caseid='%s'" % (
                        end_time, ret, start_time, step_info, casename,
                        state, taskid, scriptid)
                    self.cursor.execute(update_test_result_sql)
                    self.conn.commit()
                    fail_num = 0
                    break
                else:
                    self.run_test_case(scriptid, taskid)
                    update_test_result_sql = "UPDATE `wda_ios_result` SET endtime='%s', result='%s', starttime='%s', stepinfo='%s', casename='%s', state='%s' WHERE taskid='%s' AND caseid='%s'" % (
                        end_time, ret, start_time, step_info, casename,
                        state, taskid, scriptid)
                    self.cursor.execute(update_test_result_sql)
                    self.conn.commit()
                    fail_num = fail_num - 1

        reportpath = 'http://qam.in.za/#/uitest-test-task-list'
        update_task_sql = "UPDATE `wda_ios_task` SET taskstate='完成',reportpath='%s' where taskid='%s' " % (
            reportpath, taskid)
        # print update_task_sql
        self.cursor.execute(update_task_sql)
        self.conn.commit()
        self.get_failed_case_num(taskid)
        str = '---------------更新监控任务task %s 成功--------------' % taskid
        print(str)
    else:
        print("插入任务失败")


def retry_task_case(self, scriptid, taskid):
    start_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    result = self.run_test_case(scriptid, taskid)
    end_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    run_result = json.loads(result)
    step_info = json.dumps(run_result.get('detail'), ensure_ascii=False)
    casename = run_result.get('casename')
    state = run_result.get('state')
    ret = run_result.get('ret')
    # 用例重试成功
    if ret == 0:
        update_test_result_sql = "UPDATE `wda_ios_result` SET endtime='%s',result='%s',starttime='%s',stepinfo='%s',casename='%s',state='%s' WHERE taskid='%s' AND caseid='%s' " % (
            end_time, ret, start_time, step_info, casename, state, taskid,
            scriptid)
        # print update_test_result_sql
        self.cursor.execute(update_test_result_sql)
        self.conn.commit()
        str = '用例%s  重试成功' % scriptid
        print(str)
    else:
        update_test_result_sql = "UPDATE `wda_ios_result` SET endtime='%s',result='%s',starttime='%s',stepinfo='%s',casename='%s',state='%s' WHERE taskid='%s' AND caseid='%s' " % (
            end_time, ret, start_time, step_info, casename, state, taskid,
            scriptid)
        # print update_test_result_sql
        self.cursor.execute(update_test_result_sql)
        self.conn.commit()
        str = '用例%s  重试失败' % scriptid
        print(str)
    self.get_failed_case_num(taskid)


def retry_task_failed_case(self, scriptids, taskid):
    scriptids_array = scriptids.split(",")
    for scriptid in scriptids_array:
        self.retry_task_case(scriptid, taskid)
    self.get_failed_case_num(taskid)


def get_failed_case_num(self, taskid):
    # 计算用例总数
    sql_num = "SELECT count(1) FROM `wda_ios_result` WHERE taskid=%s " % (
        taskid)
    self.cursor = self.conn.cursor()
    self.cursor.execute(sql_num)
    rows = self.cursor.fetchall()
    case_num = ''
    for row in rows:
        case_num = row[0]
    # 计算成功用例总数
    sql_success_num = "SELECT count(1) FROM `wda_ios_result` WHERE taskid=%s AND state='成功'" % (
        taskid)
    self.cursor = self.conn.cursor()
    self.cursor.execute(sql_success_num)
    rows = self.cursor.fetchall()
    success_num = ''
    for row in rows:
        success_num = row[0]
    fail_num = int(case_num) - int(success_num)
    taskview = '%s,%s,%s' % (success_num, fail_num, case_num)
    taskstate = '完成'
    update_task_sql = "UPDATE `wda_ios_task` SET taskresult='%s',taskstate='%s' where taskid='%s' " % (
        taskview, taskstate, taskid)
    # print update_task_sql
    self.cursor.execute(update_task_sql)
    self.conn.commit()
    str = '---------------更新task %s 成功--------------' % taskid
    print(str)



'''
def download_netlog(self, url):
    print url
    # time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    date_time = time.strftime("%Y-%m-%d", time.localtime())
    file_name = '../../../wda_network_logs/%s_netlog.zip' % date_time
    r = requests.get(url)
    with open(file_name, 'wb') as f:
        f.write(r.content)
    # Retrieve HTTP meta-data
    print(r.status_code)
    print(r.headers['content-type'])
    print(r.encoding)
    print 'netlog download success'
    fsize = (os.path.getsize(file_name)) / float(1024)
    print fsize
    # 日志zip.log>10KB
    if os.path.isfile(file_name) and fsize > 10:
        unzip_cmd = 'cd ../../../wda_network_logs&&unzip -o %s_netlog.zip' % date_time
        unzip_ret = commands.getstatusoutput(unzip_cmd)
        print unzip_ret
        rename_cmd = 'cd ../../../wda_network_logs/AllLogs/DDFileLogDir&&mv com.ZhongCai500 %s* %s.log' % (
            date_time, date_time)
        rename_ret = commands.getstatusoutput(rename_cmd)
        print rename_ret

def tcpdump_start(self, taskid, scriptid):

    file_path = '../../../wda_screenshot/%s/%s.pcap' % (taskid, scriptid)
    tcpdump_cmd = 'sudo tcpdump -i rvi0 tcp port http -w %s -P' % file_path
    tcpdump_ret = commands.getstatusoutput(tcpdump_cmd)
    print tcpdump_ret

def tcpdump_end(self):

    tcpdump_cmd = 'sudo  kill $(ps aux | grep \'rvi0\' | awk \'{print $2}\') '
    tcpdump_ret = commands.getstatusoutput(tcpdump_cmd)
    print tcpdump_ret

def tcpdump_prase(self, taskid, scriptid):

    tcpdump_cmd = 'cd ../../../wda_screenshot/%s/ && parse_pcap -d m.500zhongcai.com -vvb %s.pcap>>%s.txt ' % (
        taskid, scriptid, scriptid)
    tcpdump_ret = commands.getstatusoutput(tcpdump_cmd)
    print tcpdump_ret

def install_ipa(self, package_name):
    url = 'http://qam.in.za/#/uitest-test-task-list/mobile/ios/zhongcai/43261/%s.ipa' % package_name
    file_name = '../../../wda_ppl/%s.ipa' % package_name
    urllib.urlretrieve(url, file_name)
    fsize = (os.path.getsize(file_name)) / float(1024 * 1024)
    # 覆盖率包大于50mb
    if os.path.isfile(file_name) and fsize > 50:
        install_cmd = '/usr/local/bin/ideviceinstaller -i %s' % file_name
        install_ipa_ret = commands.getstatusoutput(install_cmd)
        if str(install_ipa_ret).find('Complete'):
            create_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            appversion = '3.0.0'
            taskname = 'pipeline每日回归'
            # 成功用例，用例总数  成功，失败，总数
            taskview = 'null,null,null'
            scriptids = ''
            taskstate = '未执行'
            insert_task_sql = "INSERT INTO `wda_ios_task` (`appid`, `appname`, `appversion`, `createtime`, `creator`, `description`, `deviceinfo`, `devicelist`, `iscovered`, `mailto`, `monkeyargs`, `ostype`, `projectid`, `projectname`, `reportpath`, `result`, `scriptid`, `taskfrom`, `taskname`, `taskresult`, `taskstate`, `tasktype`, `umid`) VALUES ('001', 'com.tencent.xin', '%s', '%s', 'wuqili', '任务task', 'iPhone 7 Plus-iOS13.1\n', '10.10.86.68:8100', NULL, NULL, NULL, 'iOS', '1', '电商小程序', 'http://qam.in.za/#/uitest-test-task-list', '0', '%s', '172.16.232.171', '%s', '%s', '%s', 'iOS UI自动化测试', 'pipeline')" % (
                appversion, create_time, scriptids, taskname, taskview, taskstate)
            # print  insert_sql
            self.cursor.execute("SET NAMES utf8");
            self.cursor.execute(insert_task_sql)
            self.conn.commit()
            taskid = self.cursor.lastrowid
            state = 'install app success'
            result = {
                'taskid': taskid,
                'state': state
            }
            return json.dumps(result)
        else:
            state = 'install app failed'
            result = {
                'taskid': '-1',
                'state': state
            }
            return json.dumps(result)
    else:
        state = 'ipa file does not exists'
        result = {
            'taskid': '-1',
            'state': state
        }
        return json.dumps(result)

def get_task_status(self, taskid):
    taskstate = ''
    taskresult = ''
    reportpath = ''
    ret = '-1'
    sql_task = "SELECT taskstate,taskresult,reportpath from `mobiletest`.`wda_ios_task` WHERE taskid='%s'" % taskid
    self.cursor.execute(sql_task)
    rows = self.cursor.fetchall()
    if rows:
        for row in rows:
            ret = '0'
            taskstate = row[0]
            taskresult = row[1]
            reportpath = row[2]
    result = {
        'ret': ret,
        'taskstate': taskstate,
        'taskresult': taskresult,
        'reportpath': reportpath
    }
    return json.dumps(result)

def insert_page_speed(self, results):
    for result in results:
        print result
        insert_speed_sql = "INSERT INTO `ios_page_speed` (`cur_tab`, `page`, `start_ui`, `end_ui`, `time`) VALUES ('%s', '%s', '%s', '%s', '%s' )" % (
            result['curTab'], result['page'], result['start_ui'], result['end_ui'], result['time'])
        print  insert_speed_sql
        self.cursor.execute("SET NAMES utf8");
        self.cursor.execute(insert_speed_sql)
        self.conn.commit()
        print '插入page speed %s 成功'
'''

if __name__ == '__main__':
    engine = Engine()
