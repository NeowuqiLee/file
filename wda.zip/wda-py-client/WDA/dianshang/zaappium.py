# # -*- coding: utf-8 -*-
# import unittest
# from appium import webdriver
#
# # desired_caps = {}
# # desired_caps['platformName'] = 'iOS'
# # desired_caps['platformVersion'] = '12.4.1'
# # desired_caps['automationName'] = 'XCUITest'
# # desired_caps['deviceName'] = 'iPhone8'
# # #desired_caps['app'] = '../../apps/UICatalog.app.zip'
# # desired_caps['bundleId'] = 'com.zhonganio.zabank'
# # desired_caps['udid'] = 'c0dbc8970f5ce1eb944c6123f954646bbad97b24'
# #
# # driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)
# # driver.find_element_by_name("首页").click()
# from selenium import webdriver
#
# driver = webdriver.Chrome()
# driver.get("https://www.baidu.com/")
# driver.set_network_conditions(
#                 offline=False,
#                 latency=5,  # additional latency (ms)
#                 download_throughput=500 * 1024,  # maximal throughput
#                 upload_throughput=500 * 1024)  # maximal throughput
# print  driver.get_network_conditions()
# print driver.title
# driver.quit()

import uiautomator2 as u2

d = u2.connect('Q5S0219618001050')
# print(d.info)
pkg_name = 'com.zhongan.ibank'
d.app_start(pkg_name)
d(text="众安银行").click()
d(text="立即登录").click()
d(text="登录密码").click()
d(text="登录密码").set_text("aa1234567")
d(text="登录").click()
d.app_stop(pkg_name)
