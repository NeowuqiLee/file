# -*- coding:utf-8 -*-

import threading
import time
from urllib import parse
from http.server import BaseHTTPRequestHandler, HTTPServer
from dianshang.dbo import DBO
from dianshang.engine import Engine
import json


class Handler(BaseHTTPRequestHandler):

    def do_OPTIONS(self):
        self.send_response(200, "ok")
        self.send_header('Access-Control-Allow-Credentials', 'true')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header("Access-Control-Allow-Headers", "X-Requested-With, Content-type")

    def do_GET(self):
        rs = parse.urlparse(self.path)
        method_uri = rs.path
        method_name = method_uri[1:]

        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header("Access-Control-Allow-Headers", "X-Requested-With")
        self.send_header("Content-type", "application/json")
        self.end_headers()

        dbo = DBO()
        engine = Engine()

        # 用例部分操作
        param = parse.parse_qs(rs.query)
        if (method_name == 'debug'):
            scriptid = param['scriptid'][0]
            taskid = 0
            result = engine.run_test_case(scriptid, taskid)
            self.wfile.write(result.encode(encoding='utf_8'))
        elif (method_name == 'runTask'):
            scriptids = param['scriptids'][0]
            taskname = param['taskname'][0]
            result = engine.run_task_case(scriptids, taskname)
            # self.wfile.write(result.encode(encoding='utf_8'))
            # self.wfile.write(result)

        elif (method_name == 'retryTask'):
            scriptid = param['scriptid'][0]
            taskid = param['taskid'][0]
            # result = engine.retry_task_case(scriptid, taskid)
            # self.wfile.write(result.encode(encoding='utf_8'))

        # 纯DB操作
        elif (method_name == 'getTestReports'):
            result = dbo.get_test_reports()
            self.wfile.write(result.encode(encoding='utf_8'))
        elif (method_name == 'getReportByTaskid'):
            taskid = param['taskid'][0]
            result = dbo.get_report_by_taskid(taskid)
            self.wfile.write(result.encode(encoding='utf_8'))
        elif (method_name == 'getTestCases'):
            result = dbo.get_test_cases()
            self.wfile.write(result.encode(encoding='utf_8'))
        elif (method_name == 'getUItrace'):
            taskid = param['taskid'][0]
            result = dbo.get_ui_trace(taskid)
            self.wfile.write(result.encode(encoding='utf_8'))


        elif (method_name == 'hello'):
            data = [{'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}]
            self.wfile.write(json.dumps(data))
        else:
            print('http error')

    def do_POST(self):
        rs = parse.urlparse(self.path)
        method_name = rs.path[1:]

        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header("Access-Control-Allow-Headers", "X-Requested-With")
        self.send_header("Content-type", "application/json")
        self.send_header("Access-Control-Allow-Credentials", "true")

        self.end_headers()

        dbo = DBO()
        if (method_name == 'updateTestCase'):
            postvars = self.parse_POST()

            result = dbo.update_test_case(postvars)
            self.wfile.write(result.encode(encoding='utf_8'))

        if (method_name == 'copyTestCase'):
            postvars = self.parse_POST()
            result = dbo.copy_test_case(postvars)
            self.wfile.write(result.encode(encoding='utf_8'))

    # 获取post提交的数据
    def parse_POST(self):
        # ctype, pdict = cgi.parse_header(self.headers['content-type'])
        # print(pdict)
        # print(type(pdict))
        # if ctype == 'multipart/form-data':
        #     postvars = cgi.parse_multipart(self.rfile, pdict)
        # elif ctype == 'application/x-www-form-urlencoded':
        #     length = int(self.headers['content-length'])
        #     postvars = urllib.parse.parse_qs(
        #         self.rfile.read(length),
        #         keep_blank_values=False)

        length = int(self.headers['Content-Length'])
        post_data = parse.parse_qs(self.rfile.read(length).decode('utf-8'))
        return post_data




class MyThread(threading.Thread):
    def __init__(self, name):
        threading.Thread.__init__(self, name=name)

    def run(self):
        while True:
            # dbo().run_daily_case()
            print('i am son thread,running loop')
            time.sleep(3000)


if __name__ == '__main__':
    port = 8300
    print('starting dbo server, port', port)
    server_address = ('', port)
    httpd = HTTPServer(server_address, Handler)
    print('running server...')
    httpd.serve_forever()