# -*- coding: utf-8 -*-

import json
import time
import pymysql


class DBO(object):
    def __init__(self):
        dbconfig = {
            'host': '127.0.0.1',
            'port': 3306,
            'user': 'root',
            'passwd': '1qa2ws3ed',
            'db': 'mobiletest',
            'charset': 'utf8'
        }

        self.conn = pymysql.connect(**dbconfig)
        self.cursor = self.conn.cursor(cursor=pymysql.cursors.DictCursor)
        #         self.conn.set_character_set('utf8')
        #         self.cursor.execute('SET NAMES utf8;')
        #         self.cursor.execute('SET CHARACTER SET utf8;')
        #         self.cursor.execute('SET character_set_connection=utf8;')
        self.s = None

    def __close__(self):
        self.conn.close()

    def get_test_reports(self):
        sql = "SELECT taskid,taskname,createtime,projectname,appversion,ostype,taskstate,taskresult,umid FROM `wda_ios_task` ORDER BY createtime DESC"
        self.cursor.execute(sql)
        # 获取所有记录列表
        rows = self.cursor.fetchall()
        result = {
            'code': 200,
            'msg': 'success',
            'data': rows
        }
        return json.dumps(result)

    def get_test_cases(self):
        sql = "SELECT * FROM `tb_testcase` ORDER BY createtime DESC"
        self.cursor.execute(sql)
        # 获取所有记录列表
        rows = self.cursor.fetchall()
        result = {
            'code': 200,
            'msg': 'success',
            'data': rows
        }
        return json.dumps(result)

    def get_ui_trace(self,taskid):

        sql = "SELECT stepinfo FROM `wda_ios_result` WHERE taskid=%s" % (taskid)
        self.cursor.execute(sql)
        rows = self.cursor.fetchall()
        step_info = []
        for row in rows:
            step_info = json.loads(row['stepinfo'])
        step_tmp = []
        for step in step_info:
            tmp = {
                "startTime": int(str(step['timestamp']) + '000'),
                "uielement": step['uielement'],
                "url": "",
                "req": "",
                "res": "",
                "endTime": "",
                "time": ""
            }
            step_tmp.append(tmp)

        sql = "SELECT devicelist FROM `wda_ios_task` WHERE taskid=%s" % (taskid)
        self.cursor.execute(sql)
        rows = self.cursor.fetchall()
        interface_info = []
        for row in rows:
            interface_info = json.loads(row['devicelist'])

        interface_tmp = []
        for interfaces in interface_info:
            for interface in interfaces:
                time = int(interface['endTime']) - int(interface['startTime'])
                tmp = {
                    "startTime": interface['startTime'],
                    "uielement": "",
                    "url": interface['url'],
                    "req": interface['req'],
                    "res": interface['res'],
                    "endTime": interface['endTime'],
                    "time": time
                }
                interface_tmp.append(tmp)

        #print("共%d %d条数据" % (len(interface_tmp), len(step_tmp)))

        result = []
        while len(step_tmp) > 1:
            pre_step = step_tmp.pop(0)

            cur_step = step_tmp[0]
            interface_count=0
            for interface in interface_tmp:
                if pre_step['startTime'] < interface['startTime'] < cur_step['startTime']:
                    # result.append(interface)
                    interface_count=interface_count+1
            if interface_count!=0:
                pre_step['uielement']=pre_step['uielement']+"("+str(interface_count)+")"
            result.append(pre_step)
            for interface in interface_tmp:
                if pre_step['startTime'] < interface['startTime'] < cur_step['startTime']:
                    result.append(interface)
            if len(step_tmp)==1:
                result.append(cur_step)

        new = sorted(result, key=lambda k: k['startTime'])
        #print(newlist)
        results = {
            'code': 200,
            'msg': 'success',
            'data': new
        }
        return json.dumps(results)

    def get_report_by_taskid(self, taskid):

        # 获取任务信息
        sql = "SELECT * FROM `wda_ios_task` WHERE taskid=%s" % (taskid)
        self.cursor.execute(sql)
        task_desc = self.cursor.fetchall()

        # 获取执行详情
        sql = "SELECT * FROM `wda_ios_result` WHERE taskid=%s ORDER BY endtime DESC" % (taskid)
        self.cursor.execute(sql)
        task_dtail = self.cursor.fetchall()

        result = {
            'code': 200,
            'msg': 'success',
            'task_desc': task_desc,
            'task_dtail': task_dtail
        }
        return json.dumps(result)

    def get_report_by_taskid(self, taskid):

        # 获取任务信息
        sql = "SELECT * FROM `wda_ios_task` WHERE taskid=%s" % (taskid)
        self.cursor.execute(sql)
        task_desc = self.cursor.fetchall()

        # 获取执行详情
        sql = "SELECT * FROM `wda_ios_result` WHERE taskid=%s ORDER BY endtime DESC" % (taskid)
        self.cursor.execute(sql)
        task_dtail = self.cursor.fetchall()

        result = {
            'code': 200,
            'msg': 'success',
            'task_desc': task_desc,
            'task_dtail': task_dtail
        }
        return json.dumps(result)

    def update_test_case(self, postvars):
        result = {
            'code': 200,
            'msg': 'success',
            'update_desc': ''
        }
        description = postvars['description'][0]
        creator = postvars['creator'][0]
        projectid = postvars['projectid'][0]
        step = postvars['step'][0]
        scriptname = postvars['scriptname'][0]
        ostype = postvars['ostype'][0]
        if 'scriptid' in postvars:
            scriptid = postvars['scriptid'][0]
            create_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            update_test_case = "UPDATE `tb_testcase` SET description='%s',creator='%s',projectid='%s',step='%s',scriptname='%s',ostype='%s',createtime='%s' where scriptid='%s' " % (
                description, creator, projectid, step, scriptname, ostype, create_time, scriptid)
            print(update_test_case)
            self.cursor.execute(update_test_case)
            self.conn.commit()
            result['update_desc'] = '更新用例成功'
        else:
            create_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            insert_test_case = "INSERT INTO `tb_testcase` (`createtime`, `creator`, `description`, `ostype`, `projectid`, `scriptname`, `step`) VALUES ('%s','%s','%s','%s','%s','%s','%s')" % (
                create_time, creator, description, ostype, projectid, scriptname, step)
            print(insert_test_case)
            self.cursor.execute(insert_test_case)
            self.conn.commit()
            result['update_desc'] = '创建用例成功'
        return json.dumps(result)

    def copy_test_case(self, postvars):
        result = {
            'code': 200,
            'msg': 'success',
            'copy_desc': ''
        }
        description = postvars['description'][0]
        creator = postvars['creator'][0]
        projectid = postvars['projectid'][0]
        step = postvars['step'][0]
        scriptname = postvars['scriptname'][0]
        ostype = postvars['ostype'][0]

        create_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        insert_test_case = "INSERT INTO `tb_testcase` (`createtime`, `creator`, `description`, `ostype`, `projectid`, `scriptname`, `step`) VALUES ('%s','%s','%s','%s','%s','%s','%s')" % (
            create_time, creator, description, ostype, projectid, scriptname, step)
        print(insert_test_case)
        self.cursor.execute(insert_test_case)
        self.conn.commit()
        result['copy_desc'] = '复制用例成功'

        return json.dumps(result)


if __name__ == '__main__':
    dbo = DBO()
