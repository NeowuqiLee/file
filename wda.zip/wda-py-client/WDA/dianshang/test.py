#!/usr/bin/env python
# -*- coding: utf-8 -*-
# import MySQLdb
import datetime
import json
import os
import time
import wda
import requests
from PIL import ImageFile

'''
Created on 2017年12月18日

@author: wuqili
'''


bundle_id = 'com.zhonganio.zabank'
# # bundle_id = 'com.tencent.xin'
# wda.DEBUG = False
# c = wda.Client()
# s = c.session()


def qqLogin():
    s = c.session(bundle_id)
    assert s(name=u'我的彩票').click_exists(2.0)
    assert s(name=u'立即登录').wait(2.0)
    s(name=u'立即登录').tap()
    assert s(name=u'QQ登录', type='Button').wait()
    s(name=u'QQ登录').tap()


def screenshot():
    wda.DEBUG = True
    c.home()
    c.screenshot("1.png")


def bflive():
    s = c.session()
    s(name=u'让分', type='StaticText').tap_hold(1.0)
    s(name=u'让分', type='Other').tap_hold(1.0)
    s(name=u'让分', type='Any').tap_hold(1.0)
    # s(name=u'大小分',type='StaticText').tap_hold(1.0)




def lauch_time():
    c = wda.Client()
    start = datetime.datetime.now()
    s = c.session(bundle_id)
    count = 0
    sum_time = 0
    while (count < 9):
        ssq = s(name=u'双色球').exists
        now = datetime.datetime.now()
        if (ssq == False):
            img_path = '../../../wda_lauchtime/%s.png' % (now)
            c.screenshot(img_path)
            time.sleep(0.05)
        else:
            end = datetime.datetime.now()
            k = end - start
            print (k.total_seconds())
            sum_time = sum_time + k.total_seconds()
            count = count + 1
    avg_time = sum_time / count


def merge_txt_file():
    data = []
    for root, dirs, files in os.walk("/Users/wuqili/Downloads/networklog/"):
        for file in files:
            # 获取文件所属目录
            # print(root)
            # 获取文件路径
            txt_path = os.path.join(root, file)
            if txt_path == '/Users/wuqili/Downloads/networklog/.DS_Store':
                continue
            print(txt_path)

            with open(txt_path, 'r') as f:
                data_tmp = json.load(f)
                # print data_tmp
                data.append(data_tmp)
    with open('/Users/wuqili/Downloads/networklog/data.json', 'w') as f:
        json.dump(data, f)


def test():
    a=s(value=u'使用新卡支付').exists
    print(a)
    key='使用新卡支付'
    s.tap(360,711)


def search():
    """
    :type nums: List[int]
    :type target: int
    :rtype: int
    """
    nums=[4,5,6,7,0,1,2]
    target=0
    if len(nums)==0:return -1
    right=len(nums)-1
    left=0
    mid=(left+right+1)/2
    while(left<right):
        if(nums[mid]<target):
            right=mid
            left=left+1
        elif(nums[mid]>target):
            left=mid
            right=right-1
        else:
            return mid
        return -1

def getsizes(url):
    proxy="http://127.0.0.1:12639"
    proxyDict = {
        "http": proxy,
        "https": proxy
    }
    resp = requests.head(url, proxies=proxyDict)
    print (resp.headers['content-length'])

if __name__ == '__main__':
    #test()
    #getsizes("https://baike-med-1256891581.file.myqcloud.com/2020068/ffa3b770-abd3-11ea-9fa6-1b54b834df99_0.png")
    #getsizes("https://baike-med-1256891581.file.myqcloud.com/2020066/ff4f7cf0-abd3-11ea-801d-17c1098d7454_0.png")
    #getsizes("http://download3.navicat.com/download/navicat121_premium_cs.dmg")
    getsizes("http://download3.navicat.com/download/navicat121_premium_cs.dmg")

    #merge_txt_file()
    # lauch_time()
    # qqLogin()
