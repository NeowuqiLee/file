# -*- coding: UTF-8 -*-

import os, json, csv, codecs

class iOS_Performance(object):
    '''
    def __init__(self):
        with SSHTunnelForwarder(
                ('172.16.6.30', 35000),  # 指定ssh登录的跳转机的address，端口号
                ssh_username="root",  # 跳转机的用户
                ssh_pkey="/Users/liwuqi/.ssh/authorized_keys",  # 私钥路径
                ssh_private_key_password="",  # 密码（电脑开机密码）
                remote_bind_address=('172.16.6.183', 8639)) as server:  # mysql服务器的address，端口号
            self.conn = pymysql.connect(host='127.0.0.1',  # 此处必须是是127.0.0.1
                                        port=server.local_bind_port,
                                        user='root',  # 数据库用户名
                                        passwd='ZaBank@01T!Mgt',  # 数据库密码
                                        db='mobiletest')
            self.cursor = self.conn.cursor()
    def __close__(self):
        if self.cursor and self.conn:
            self.cursor.close()
            self.conn.close()
    '''

    def readLineFromFile(self):
        results = []
        fo = open('/Users/liwuqi/Downloads/iOS-Performance/0.7-ekyc.txt', "r")
        line = fo.readline()
        while line:
            value = {"date": "", "time": "", "cpuusage": "", "ramusage": "", "fps": ""}
            line = fo.readline()
            strArr = line.split("|")
            for str in strArr:
                if str.find("2019-") != -1:
                    value["date"] = str[0:9]
                    value['time'] = str[10:18]
                elif str.find("cpuusage:") != -1:
                    value['cpuusage'] = str[10:-2]
                elif str.find("ramusage:") != -1:
                    value['ramusage'] = str[10:-2]
                elif str.find("fps:") != -1:
                    value['fps'] = str[5:-2]
            if value["date"] and value["time"] and value["cpuusage"] and value["ramusage"] and value["fps"]:
                results.append(value)
        fo.close()
        return results

    def insertdb(self, data):
        app_version = '0.7'
        performance_type = 'common'
        performance_info = json.dumps(data)
        screenshots_url = 'http://bank-tools-test.zatech.com:8007/Screenshot/show'
        starttime = '2019-07-17 16:36:50'
        endtime = '2019-07-17 16:56:24'
        insert_cmd = "INSERT INTO `mobiletest`.`za_app_performance`(`app_version`, `app_packge_name`, `performance_type`, `performance_info`, `mobile_device_name`, `mobile_platform`, `mobile_os_version`, `business_module`, `screenshots_url`, `starttime`, `endtime`) VALUES ('%s', 'com.zhonganio.zabank', '%s', '%s', 'iPhone7', 'iOS', '11.3', 'ekyc', '%s', '%s', '%s')" % (
        app_version, performance_type, performance_info, screenshots_url, starttime, endtime)
        print insert_cmd

    def json2csv(self, data):
        csv_path = '/Users/liwuqi/Downloads/ios-0.7-ekyc.csv'
        delete_cmd = "rm -f " + csv_path
        if os.path.isfile(csv_path):
            os.system(delete_cmd)
        fo = file(csv_path, 'wb')
        fo.write(codecs.BOM_UTF8)
        csvwriter = csv.writer(fo)
        csvwriter.writerow(["date", "time", "cpuusage", "ramusage", "fps"])
        csv_data = list()
        print type(data)
        for val in data:
            row = list()
            row.append(val['date'])
            row.append(val['time'])
            row.append(val['cpuusage'])
            row.append(val['ramusage'])
            row.append(val['fps'])
            csv_data.append(row)
        # 简单排序，方便查看
        csv_data.sort()
        for row in csv_data:
            csvwriter.writerow(row)
        print "共计%s条数据" % len(csv_data)
        fo.close()

        open_cmd = "open " + csv_path
        os.system(open_cmd)


if __name__ == '__main__':
    ios = iOS_Performance()
    data = ios.readLineFromFile()
    ios.insertdb(data)
    ios.json2csv(data)
    # ios.__close__()
