# -*- coding: UTF-8 -*-

import requests
import pathlib
from datetime import datetime
import re


def read_jce():
    path = "/Users/wuqili/Documents/UGit/sppjce/Umall/"
    for file in pathlib.Path(path).glob('**/*.jce'):
        with open(file, 'r', encoding='UTF-8', errors='replace') as f:
            content = f.read()
            result = re.findall(r'(interface[ ]{0,}\S+)[ ]{0,}{{0,1}', content)
            if len(result) > 0:
                interface_namespace = result[0].replace('{', '').replace('interface', '').strip()
                #print(interface_namespace)
                interface_str_index = content.find("interface")
                interface_content = content[interface_str_index: content.find('}', interface_str_index)]
                jce_interface = re.findall(r"(int|string|void|bool)[ ]{0,}(\S+)[ ]{0,}\((.+)\)", interface_content)
                for item in jce_interface:
                    # print("moudule"+interface_namespace)
                    # print("method"+item[0])
                    print("interface " + item[1])
                    # print("param"+item[2])
                    vincen(interface_namespace,item[1],item[2],item[0])
                    # if(item[1]!="hello"):
                    #     print(item[0])
                    #     print("======"+item[1])
                    #print(item[2])

# def get_interface_list_from_jce(jce_content):
#     interface_namespace = ''
#     interface_list = []
#     # interface namespace
#     regex = r'interface[ ]{0,}\S+[ ]{0,}{{0,1}'
#     result = re.findall(regex, jce_content)
#     if len(result) != 0:
#         interface_namespace = result[0][9:].split('//')[0].replace('{', '')
#         interface_namespace = interface_namespace.replace(' ', '')
#     # interface list
#     # One of regex : int[ ]{0,}\S+[ ]{0,}\(
#     regex = r'(int[ ]{0,}\S+[ ]{0,}\(|string[ ]{0,}\S+[ ]{0,}\(|void[ ]{0,}\S+[ ]{0,}\(|bool[ ]{0,}\S+[ ]{0,}\()'
#     result = re.findall(regex, jce_content)
#     if result is not None:
#         for iter in result:
#             iter = iter.split(';')[0].replace('int ', '')
#             iter = iter.split(';')[0].replace('string ', '')
#             iter = iter.split(';')[0].replace('void ', '')
#             iter = iter.split(';')[0].replace('bool ', '')
#             iter = iter.replace('(', '')
#             interface_list.append(iter.strip())
#     print(interface_list)
#     return interface_namespace, interface_list
def vincen(name,interface,param,method):
    formal_url = 'http://gan.oa.com/apitest/APIDataReport'
    time=datetime.now().strftime("%Y-%m-%d %H:%M")
    body = {
        "user_token": "2bb5d0cac63f11eaaa14f2189858136d",  # str, 鉴权token, 需要的时候找vincentgan生成，永久有效
        "api_list": [
            {  # 以下为必填，不能空着
                "last_modified_time": time,  # str, 固定格式，接口最后修改时间

                "project": "腾讯健康商城",  # str, 项目名（建议用中文，直接展示到前端）
                "module": "",  # str, 模块名
                "service": name,  # str, 服务名
                "interface_name": interface,  # str, 接口名
                "covered": False, # boolean, 覆盖状态，True or False

                # 必填，但可以空着
                "service_type": "srf",  # str, 服务类型(Taf, http等)
                "CI_status": "QCI",  # str, CI情况(QCI, 蓝盾流水线, 人工等，视项目情况而定)
                "CD_status": "QCI",  # str, CD情况(QCI, 蓝盾流水线, 人工等，视项目情况而定)
                "monitor": "0",  # str, 监控情况(Taf监控等，视项目情况而定)
                "alert": "0",  # str, 开发者(Taf告警等，视项目情况而定)
                "netgate_service": "",  # str, 网关服务名

                # 必填，但可以空着
                "developer": "simonsmchen",  # str, 开发者
                "provider": "https://git.code.oa.com/drug-mall/sppjce",  # str, 提供方
                "caller": "wuqili",  # str, 调用方
                "remark": "1",  # str, 备注

                "url": "",  # request url
                "body": "",  # request body
                "header": "",  # request header
                "api_params": param,  # jce中接口入参
                "api_output": method,  # jce中接口类型

            }
        ]
    }

    headers = {
        'Content-Type': 'application/json;charset=utf-8'
    }
    response = requests.post(url=formal_url, json=body, headers=headers)
    print(response)

if __name__ == '__main__':
    read_jce()

