/*
 Navicat Premium Data Transfer

 Source Server         : 172.16.6.183
 Source Server Type    : MySQL
 Source Server Version : 50721
 Source Host           : 172.16.6.183:8639
 Source Schema         : mobiletest

 Target Server Type    : MySQL
 Target Server Version : 50721
 File Encoding         : 65001

 Date: 12/03/2020 11:25:27
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_testcase
-- ----------------------------
DROP TABLE IF EXISTS `tb_testcase`;
CREATE TABLE `tb_testcase` (
  `scriptid` int(11) NOT NULL AUTO_INCREMENT,
  `common` varchar(255) DEFAULT NULL,
  `createtime` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `ostype` varchar(255) DEFAULT NULL,
  `pre_script` varchar(255) DEFAULT NULL,
  `projectid` int(11) DEFAULT NULL,
  `projectname` varchar(255) DEFAULT NULL,
  `scriptname` varchar(255) DEFAULT NULL,
  `step` longtext,
  `tag` varchar(255) DEFAULT NULL,
  `umid` varchar(255) DEFAULT NULL,
  `tooltype` varchar(255) DEFAULT NULL,
  `commonid` varchar(255) DEFAULT NULL,
  `cleardata` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`scriptid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=20026 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for wda_ios_result
-- ----------------------------
DROP TABLE IF EXISTS `wda_ios_result`;
CREATE TABLE `wda_ios_result` (
  `reportid` int(11) NOT NULL AUTO_INCREMENT,
  `endtime` varchar(255) DEFAULT NULL,
  `loginfo` longtext,
  `result` varchar(255) DEFAULT NULL,
  `runtime` varchar(255) DEFAULT NULL,
  `starttime` varchar(255) DEFAULT NULL,
  `stepinfo` longtext,
  `taskid` int(11) DEFAULT NULL,
  `umid` varchar(255) DEFAULT NULL,
  `caseid` int(11) DEFAULT NULL,
  `casename` varchar(255) DEFAULT NULL,
  `tooltype` varchar(255) DEFAULT NULL,
  `deviceinfo` varchar(255) DEFAULT NULL,
  `passrate` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `performanceData` text,
  `versionTag` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`reportid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=20898 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for wda_ios_task
-- ----------------------------
DROP TABLE IF EXISTS `wda_ios_task`;
CREATE TABLE `wda_ios_task` (
  `taskid` int(11) NOT NULL AUTO_INCREMENT,
  `appid` int(11) DEFAULT NULL,
  `appname` varchar(255) DEFAULT NULL,
  `appversion` varchar(255) DEFAULT NULL,
  `createtime` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `deviceinfo` varchar(255) DEFAULT NULL,
  `devicelist` varchar(255) DEFAULT NULL,
  `iscovered` varchar(255) DEFAULT NULL,
  `mailto` varchar(255) DEFAULT NULL,
  `monkeyargs` varchar(255) DEFAULT NULL,
  `ostype` varchar(255) DEFAULT NULL,
  `projectid` int(11) DEFAULT NULL,
  `projectname` varchar(255) DEFAULT NULL,
  `reportpath` varchar(255) DEFAULT NULL,
  `result` longtext,
  `scriptid` longtext,
  `taskfrom` varchar(255) DEFAULT NULL,
  `taskname` varchar(255) DEFAULT NULL,
  `taskresult` varchar(255) DEFAULT NULL,
  `taskstate` varchar(255) DEFAULT NULL,
  `tasktype` varchar(255) DEFAULT NULL,
  `umid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`taskid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=805 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

SET FOREIGN_KEY_CHECKS = 1;
